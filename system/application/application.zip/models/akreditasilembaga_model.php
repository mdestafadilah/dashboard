		<?
class akreditasilembaga_model extends Model{
function akreditasilembaga_model(){
parent::Model();
$this->load->database();
}
var $table='akreditasilembaga';

function get_all_data($start,$limit,$q,$s,$st,$pr){
	 $this->db->select('*');
        $this->db->from($this->table);
		$this->db->join('lembaga','lembaga.id_lembaga=akreditasilembaga.id_lembaga','left');
		$this->db->join('provinsi','lembaga.id_provinsi=provinsi.id_provinsi','left');
		$this->db->join('kabupatenkota','lembaga.id_kabupatenkota=kabupatenkota.id_kabupatenkota','left');
		$this->db->join('program','program.id_program=akreditasilembaga.id_program','left');
		//$this->db->join('asesor','asesor.id_asesor=akreditasilembaga.asesor1','left');
		if($s!=0){
		if($q!='0')$this->db->or_like('lembaga.nama_lembaga',$q);
		if($pr!='0')$this->db->where('provinsi.id_provinsi',$pr);
		if($st!='3')$this->db->where('akreditasilembaga.status',$st);
		/*$this->db->or_like('id_lembaga',$q);
$this->db->or_like('status',$q);
$this->db->or_like('tgl_akreditasi',$q);
$this->db->or_like('id_program',$q);
$this->db->or_like('asesor1',$q);
$this->db->or_like('asesor2',$q);
*/
        }
        $this->db->limit($limit, $start);
		return $this->db->get();
	

}


function count_all(){
return $this->db->count_all($this->table);
}
 function getData($id){
return $this->db->get_where($this->table, array('id_akreditasilembaga'=>$id));
}
function delete_data($id){

   return $this->db->delete($this->table, array('id_akreditasilembaga' => $id)); 
}
function update_data($data,$id){
  $this->db->where('id_akreditasilembaga', $id);
  $this->db->update($this->table, $data);
  return TRUE;

}
function add_data($data){
return $this->db->insert($this->table,$data);

}

}
?>		