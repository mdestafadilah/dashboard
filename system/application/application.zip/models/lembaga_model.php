		<?
class lembaga_model extends Model{
function lembaga_model(){
parent::Model();
$this->load->database();
}
var $table='lembaga';

function get_all_data($start,$limit,$q,$s){
	 $this->db->select('*');
        $this->db->from($this->table);
		$this->db->join('provinsi','lembaga.id_provinsi=provinsi.id_provinsi','left');
		$this->db->join('kabupatenkota','lembaga.id_kabupatenkota=kabupatenkota.id_kabupatenkota','left');
		//$this->db->join('program','lembaga.id_program=program.id_program','left');

		if($s!=0){
		$this->db->or_like('lembaga.nama_lembaga',$q);
$this->db->or_like('lembaga.nilek_nilem',$q);
//$this->db->or_like('program.kode_program',$q);
$this->db->or_like('lembaga.nomor_skpendirian',$q);
$this->db->or_like('lembaga.tanggal_skpendirian',$q);
$this->db->or_like('lembaga.skpendirian_ditandatanganioleh',$q);
$this->db->or_like('lembaga.nomor_suratizinoperasionallembaga',$q);
$this->db->or_like('lembaga.tanggal_suratizinoperasionallembaga',$q);
$this->db->or_like('lembaga.suratizinoperasionallembaga_diterbitkanoleh',$q);
$this->db->or_like('lembaga.masaberlaku_suratizinoperasionallembaga',$q);
$this->db->or_like('lembaga.alamat',$q);
$this->db->or_like('lembaga.telepon',$q);
$this->db->or_like('lembaga.hp',$q);
$this->db->or_like('lembaga.faksimili',$q);
$this->db->or_like('lembaga.email',$q);
$this->db->or_like('lembaga.homepage',$q);

        }
        $this->db->limit($limit, $start);
		return $this->db->get();
	

}


function count_all(){
return $this->db->count_all($this->table);
}
 function getData($id){
return $this->db->get_where($this->table, array('id_lembaga'=>$id));
}
function delete_data($id){

   return $this->db->delete($this->table, array('id_lembaga' => $id)); 
}
function update_data($data,$id){
  $this->db->where('id_lembaga', $id);
  $this->db->update($this->table, $data);
  return TRUE;

}
function add_data($data){
return $this->db->insert($this->table,$data);

}

}
?>		