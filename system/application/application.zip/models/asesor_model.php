		<?
class asesor_model extends Model{
function asesor_model(){
parent::Model();
$this->load->database();
}
var $table='asesor';

function get_all_data($start,$limit,$q,$s,$st){
	 $this->db->select('*');
        $this->db->from($this->table);
			$this->db->join('provinsi','asesor.id_provinsi=provinsi.id_provinsi','left');
		$this->db->join('kabupatenkota','asesor.id_kabupatenkota=kabupatenkota.id_kabupatenkota','left');
		$this->db->join('program','asesor.id_program=program.id_program','left');
		$this->db->join('jabatan','jabatan.id_jabatan=asesor.id_jabatan','left');
		if($s!=0){
		//$this->db->or_like('asesor.no_urut_asesor',$q);
if($q!='0')
$this->db->or_like('asesor.nama',$q);
/*$this->db->or_like('asesor.angkatan',$q);
$this->db->or_like('asesor.bulan',$q);
$this->db->or_like('asesor.tahun',$q);
$this->db->or_like('program.kode_program',$q);
$this->db->or_like('asesor.jenis_kelamin',$q);
$this->db->or_like('asesor.alamat_surat_menyurat',$q);
$this->db->or_like('asesor.alamat_kantor',$q);
$this->db->or_like('asesor.email',$q);
$this->db->or_like('asesor.telepon',$q);
$this->db->or_like('jabatan.jabatan',$q);*/
if($st!='3'){
$this->db->where('asesor.status',$st);
}
/*$this->db->or_like('asesor.angkatan_asesor',$q);
$this->db->or_like('asesor.no_sertifikat',$q);
*/
        }
        $this->db->limit($limit, $start);
		return $this->db->get();
	

}


function count_all(){
return $this->db->count_all($this->table);
}
 function getData($id){
return $this->db->get_where($this->table, array('id_asesor'=>$id));
}
function delete_data($id){

   return $this->db->delete($this->table, array('id_asesor' => $id)); 
}
function update_data($data,$id){
  $this->db->where('id_asesor', $id);
  $this->db->update($this->table, $data);
  return TRUE;

}
function add_data($data){
return $this->db->insert($this->table,$data);

}

}
?>		