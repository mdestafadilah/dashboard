		<?
class permohonan_model extends Model{
function permohonan_model(){
parent::Model();
$this->load->database();
}
var $table='permohonan';

function get_all_data($start,$limit,$q,$s){
	 $this->db->select('*');
        $this->db->from($this->table);
	    $this->db->join('program','permohonan.id_program=program.id_program','left');
		$this->db->join('lembaga','lembaga.id_lembaga=permohonan.id_lembaga','left');
		$this->db->where('permohonan.type',1);
		if($s!=0){
		$this->db->or_like('permohonan.no_permohonan',$q);
$this->db->or_like('permohonan.tgl_terimasurat',$q);
$this->db->or_like('permohonan.no_surat',$q);
$this->db->or_like('permohonan.pemohon',$q);
$this->db->or_like('lembaga.nama_lembaga',$q);
$this->db->or_like('keterangan',$q);

        }
        $this->db->limit($limit, $start);
		return $this->db->get();
	

}


function count_all(){
return $this->db->count_all($this->table);
}
 function getData($id){
return $this->db->get_where($this->table, array('id_permohonan'=>$id));
}
function delete_data($id){

   return $this->db->delete($this->table, array('id_permohonan' => $id)); 
}
function update_data($data,$id){
  $this->db->where('id_permohonan', $id);
  $this->db->update($this->table, $data);
  return TRUE;

}
function add_data($data){
return $this->db->insert($this->table,$data);

}

}
?>		