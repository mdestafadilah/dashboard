<?php

class dokumenasesor extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('dokumenasesor_model');
		
		    }


    public function index($id)
    {
	$data['id']=$id;
	$asesor=$this->db->query("select * from asesor where id_asesor='$id'")->row();
	$data['nama']=$asesor->nama;
	
	 $this->load->view('dokumenasesor/listdokumenasesor',$data);
	}
	
	
	 public function get_all_data($id)
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query("select count(*) as total from dokumenasesor where id_asesor='$id'")->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->dokumenasesor_model->get_all_data($start,$limit,$q,$s,$id);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_dokumenasesor'=>$obj->id_dokumenasesor,

'id_asesor'=>$obj->id_asesor,
'judul_dokumen'=>$obj->judul_dokumen,
'deskripsi'=>$obj->deskripsi,
'nama_file'=>$obj->nama_file,
'tgl_upload'=>$obj->tgl_upload

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
		/*$config['upload_path'] = './uploads/asesor/';
		//$config['allowed_types'] = 'gif|jpg|png';
		//$config['max_size']	= '100';
		//$config['max_width']  = '1024';
		//$config['max_height']  = '768';
	$this->load->library('upload', $config);
	if ( ! $this->upload->do_upload('nama_file'))
		{ echo '{success:failed}';
		}
		else{
		$dok=$this->upload->data('');*/
		$acak = rand(0000,9999);
		$file=$_FILES['nama_file']['name'];
		$file=ereg_replace("-","_",$file);
			$file=ereg_replace("'","_",$file);
			$file=explode(".",ereg_replace(",","_",$file));
			$nama_file=substr($file[0],0,15).$acak.".".$file[1];
		move_uploaded_file ($_FILES['nama_file']['tmp_name'],"assets/upload/asesor/".$nama_file);
	
	$Data=array(
	'id_asesor'=>$this->input->post('id_asesor'),
'judul_dokumen'=>$this->input->post('judul_dokumen'),
'deskripsi'=>$this->input->post('deskripsi'),
'nama_file'=>$nama_file,
'tgl_upload'=>date("F j, Y, g:i a")
 
	 );
		$add=$this->dokumenasesor_model->add_data($Data);
		 echo '{success:true}';
	//}
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
		 unlink("assets/upload/asesor/".$id);
         $query=$this->dokumenasesor_model->delete_data($id);
				 
				 
               
		}
    }
	

	
	public function getData($id){
	
	$query=$this->dokumenasesor_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_dokumenasesor'=>$obj->id_dokumenasesor,

			'id_asesor'=>$obj->id_asesor,
'judul_dokumen'=>$obj->judul_dokumen,
'deskripsi'=>$obj->deskripsi,
'nama_file'=>$obj->nama_file,
'tgl_upload'=>$obj->tgl_upload

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	//$id_asesor=trim($this->input->post('id_asesor'));
$judul_dokumen=trim($this->input->post('judul_dokumen'));
$deskripsi=trim($this->input->post('deskripsi'));
$nama_file=trim($this->input->post('nama_file'));
//$tgl_upload=trim($this->input->post('tgl_upload'));

   
	$id=$this->input->post('id_dokumenasesor');
	
	
	
	$Data=array(
	//'id_asesor'=>$this->input->post('id_asesor'),
'judul_dokumen'=>$this->input->post('judul_dokumen'),
'deskripsi'=>$this->input->post('deskripsi'),
//'nama_file'=>$this->input->post('nama_file'),
//'tgl_upload'=>$this->input->post('tgl_upload')

	);



	 	$edit=$this->dokumenasesor_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

