<?php

class skpendirian extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('skpendirian_model');
		
		    }


    public function index()
    {
	 $this->load->view('skpendirian/listskpendirian');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from skpendirian')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->skpendirian_model->get_all_Data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_skpendirian'=>$obj->id_skpendirian,

			'nomor'=>$obj->nomor,
'tanggal'=>$obj->tanggal,
'ditandatangani_oleh'=>$obj->ditandatangani_oleh

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'nomor'=>$this->input->post('nomor'),
'tanggal'=>$this->input->post('tanggal'),
'ditandatangani_oleh'=>$this->input->post('ditandatangani_oleh')
 
	 );
		$add=$this->skpendirian_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->skpendirian_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->skpendirian_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_skpendirian'=>$obj->id_skpendirian,

			'nomor'=>$obj->nomor,
'tanggal'=>$obj->tanggal,
'ditandatangani_oleh'=>$obj->ditandatangani_oleh

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$nomor=trim($this->input->post('nomor'));
$tanggal=trim($this->input->post('tanggal'));
$ditandatangani_oleh=trim($this->input->post('ditandatangani_oleh'));

   
	$id=$this->input->post('id_skpendirian');
	
	
	
	$Data=array(
	'nomor'=>$this->input->post('nomor'),
'tanggal'=>$this->input->post('tanggal'),
'ditandatangani_oleh'=>$this->input->post('ditandatangani_oleh')

	);



	 	$edit=$this->skpendirian_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

