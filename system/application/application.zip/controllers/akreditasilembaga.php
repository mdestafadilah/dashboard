<?php

class akreditasilembaga extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('akreditasilembaga_model');
		
		    }


    public function index()
    {
	 $this->load->view('akreditasilembaga/listakreditasilembaga');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from akreditasilembaga')->row();
        $arr = array();
		if (isset($_POST['task'])){
		if($_POST['task']=='cari'){
		if($_POST['status']=="")$st=3;
		else $st=$_POST['status'];
		if($_POST['provinsi']=='0')$pr=0;
		else $pr=$_POST['provinsi'];

		if($_POST['nama']=="")$nm=0;
		else $nm=$_POST['nama'];
		$q=$nm;$s=1;
		}
		if($_POST['task']=='data'){
		$q='';$s=0;$st=3;$pr=0;
		}
		}
		else {$q='';$s=0;$st=3;$pr=0;}
		$query=$this->akreditasilembaga_model->get_all_data($start,$limit,$q,$s,$st,$pr);
			$status='null';	
		
        foreach ($query->result() as $obj)
        {
		    if($obj->status==0)$status2='<span style="color:red">Belum terakreditasi</span>';
			else if($obj->status==1)$status2='<span style="color:blue">Terakreditasi</span>';
			else if($obj->status==2)$status2='<span style="color:red">Ditunda</span>';
	$asesorsql2=$this->db->query("select nama from asesor where id_asesor='".$obj->asesor2."' limit 1")->row();
	$asesorsql=$this->db->query("select nama from asesor where id_asesor='".$obj->asesor1."' limit 1")->row();
            $arr[] =array(
			'id_akreditasilembaga'=>$obj->id_akreditasilembaga,

			'id_lembaga'=>$obj->nama_lembaga,
'status'=>$status2,
'tgl_akreditasi'=>str_replace("-","/",$obj->tgl_akreditasi),
'id_program'=>$obj->nama_program,
'asesor1'=>$asesorsql->nama,
'kabupaten_kota'=>$obj->kabupaten_kota,
'provinsi'=>$obj->provinsi,
'asesor2'=>$asesorsql2->nama

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'id_lembaga'=>$this->input->post('id_lembaga'),
'status'=>$this->input->post('status'),
'tgl_akreditasi'=>$this->input->post('tgl_akreditasi'),
'id_program'=>$this->input->post('id_program'),
'asesor1'=>$this->input->post('asesor1'),
'asesor2'=>$this->input->post('asesor2')
 
	 );
		$add=$this->akreditasilembaga_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->akreditasilembaga_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->akreditasilembaga_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_akreditasilembaga'=>$obj->id_akreditasilembaga,

			'id_lembaga'=>$obj->id_lembaga,
'status'=>$obj->status,
'tgl_akreditasi'=>$obj->tgl_akreditasi,
'id_program'=>$obj->id_program,
'asesor1'=>$obj->asesor1,
'asesor2'=>$obj->asesor2

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$id_lembaga=trim($this->input->post('id_lembaga'));
$status=trim($this->input->post('status'));
$tgl_akreditasi=trim($this->input->post('tgl_akreditasi'));
$id_program=trim($this->input->post('id_program'));
$asesor1=trim($this->input->post('asesor1'));
$asesor2=trim($this->input->post('asesor2'));

   
	$id=$this->input->post('id_akreditasilembaga');
	
	
	
	$Data=array(
	'id_lembaga'=>$this->input->post('id_lembaga'),
'status'=>$this->input->post('status'),
'tgl_akreditasi'=>$this->input->post('tgl_akreditasi'),
'id_program'=>$this->input->post('id_program'),
'asesor1'=>$this->input->post('asesor1'),
'asesor2'=>$this->input->post('asesor2')

	);



	 	$edit=$this->akreditasilembaga_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

