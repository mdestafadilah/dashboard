<?php

class lembaga extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('lembaga_model');
		
		    }


    public function index()
    {
	 $this->load->view('lembaga/listlembaga');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from lembaga')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->lembaga_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_lembaga'=>$obj->id_lembaga,

			'nama_lembaga'=>$obj->nama_lembaga,
'nilek_nilem'=>$obj->nilek_nilem,
//'id_program'=>$obj->kode_program,
'nomor_skpendirian'=>$obj->nomor_skpendirian,
'tanggal_skpendirian'=>str_replace("-","/",$obj->tanggal_skpendirian),
'skpendirian_ditandatanganioleh'=>$obj->skpendirian_ditandatanganioleh,
'nomor_suratizinoperasionallembaga'=>$obj->nomor_suratizinoperasionallembaga,
'tanggal_suratizinoperasionallembaga'=>str_replace("-","/",$obj->tanggal_suratizinoperasionallembaga),
'suratizinoperasionallembaga_diterbitkanoleh'=>$obj->suratizinoperasionallembaga_diterbitkanoleh,
'masaberlaku_suratizinoperasionallembaga'=>$obj->masaberlaku_suratizinoperasionallembaga,
'alamat'=>$obj->alamat,
'id_kabupatenkota'=>$obj->kabupaten_kota,
'id_provinsi'=>$obj->provinsi,
'telepon'=>$obj->telepon,
'hp'=>$obj->hp,
'faksimili'=>$obj->faksimili,
'email'=>$obj->email,
'homepage'=>$obj->homepage

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'nama_lembaga'=>$this->input->post('nama_lembaga'),
'nilek_nilem'=>$this->input->post('nilek_nilem'),
//'id_program'=>$this->input->post('id_program'),
'nomor_skpendirian'=>$this->input->post('nomor_skpendirian'),
'tanggal_skpendirian'=>$this->input->post('tanggal_skpendirian'),
'skpendirian_ditandatanganioleh'=>$this->input->post('skpendirian_ditandatanganioleh'),
'nomor_suratizinoperasionallembaga'=>$this->input->post('nomor_suratizinoperasionallembaga'),
'tanggal_suratizinoperasionallembaga'=>$this->input->post('tanggal_suratizinoperasionallembaga'),
'suratizinoperasionallembaga_diterbitkanoleh'=>$this->input->post('suratizinoperasionallembaga_diterbitkanoleh'),
'masaberlaku_suratizinoperasionallembaga'=>$this->input->post('masaberlaku_suratizinoperasionallembaga'),
'alamat'=>$this->input->post('alamat'),
'id_kabupatenkota'=>$this->input->post('id_kabupatenkota'),
'id_provinsi'=>$this->input->post('id_provinsi'),
'telepon'=>$this->input->post('telepon'),
'hp'=>$this->input->post('hp'),
'faksimili'=>$this->input->post('faksimili'),
'email'=>$this->input->post('email'),
'homepage'=>$this->input->post('homepage')
 
	 );
		$add=$this->lembaga_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->lembaga_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->lembaga_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_lembaga'=>$obj->id_lembaga,

			'nama_lembaga'=>$obj->nama_lembaga,
'nilek_nilem'=>$obj->nilek_nilem,
//'id_program'=>$obj->id_program,
'nomor_skpendirian'=>$obj->nomor_skpendirian,
'tanggal_skpendirian'=>$obj->tanggal_skpendirian,
'skpendirian_ditandatanganioleh'=>$obj->skpendirian_ditandatanganioleh,
'nomor_suratizinoperasionallembaga'=>$obj->nomor_suratizinoperasionallembaga,
'tanggal_suratizinoperasionallembaga'=>$obj->tanggal_suratizinoperasionallembaga,
'suratizinoperasionallembaga_diterbitkanoleh'=>$obj->suratizinoperasionallembaga_diterbitkanoleh,
'masaberlaku_suratizinoperasionallembaga'=>$obj->masaberlaku_suratizinoperasionallembaga,
'alamat'=>$obj->alamat,
'id_kabupatenkota'=>$obj->id_kabupatenkota,
'id_provinsi'=>$obj->id_provinsi,
'telepon'=>$obj->telepon,
'hp'=>$obj->hp,
'faksimili'=>$obj->faksimili,
'email'=>$obj->email,
'homepage'=>$obj->homepage

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$nama_lembaga=trim($this->input->post('nama_lembaga'));
$nilek_nilem=trim($this->input->post('nilek_nilem'));
//$id_program=trim($this->input->post('id_program'));
$nomor_skpendirian=trim($this->input->post('nomor_skpendirian'));
$tanggal_skpendirian=trim($this->input->post('tanggal_skpendirian'));
$skpendirian_ditandatanganioleh=trim($this->input->post('skpendirian_ditandatanganioleh'));
$nomor_suratizinoperasionallembaga=trim($this->input->post('nomor_suratizinoperasionallembaga'));
$tanggal_suratizinoperasionallembaga=trim($this->input->post('tanggal_suratizinoperasionallembaga'));
$suratizinoperasionallembaga_diterbitkanoleh=trim($this->input->post('suratizinoperasionallembaga_diterbitkanoleh'));
$masaberlaku_suratizinoperasionallembaga=trim($this->input->post('masaberlaku_suratizinoperasionallembaga'));
$alamat=trim($this->input->post('alamat'));
$id_kabupatenkota=trim($this->input->post('id_kabupatenkota'));
$id_provinsi=trim($this->input->post('id_provinsi'));
$telepon=trim($this->input->post('telepon'));
$hp=trim($this->input->post('hp'));
$faksimili=trim($this->input->post('faksimili'));
$email=trim($this->input->post('email'));
$homepage=trim($this->input->post('homepage'));

   
	$id=$this->input->post('id_lembaga');
	
	
	
	$Data=array(
	'nama_lembaga'=>$this->input->post('nama_lembaga'),
'nilek_nilem'=>$this->input->post('nilek_nilem'),
//'id_program'=>$this->input->post('id_program'),
'nomor_skpendirian'=>$this->input->post('nomor_skpendirian'),
'tanggal_skpendirian'=>$this->input->post('tanggal_skpendirian'),
'skpendirian_ditandatanganioleh'=>$this->input->post('skpendirian_ditandatanganioleh'),
'nomor_suratizinoperasionallembaga'=>$this->input->post('nomor_suratizinoperasionallembaga'),
'tanggal_suratizinoperasionallembaga'=>$this->input->post('tanggal_suratizinoperasionallembaga'),
'suratizinoperasionallembaga_diterbitkanoleh'=>$this->input->post('suratizinoperasionallembaga_diterbitkanoleh'),
'masaberlaku_suratizinoperasionallembaga'=>$this->input->post('masaberlaku_suratizinoperasionallembaga'),
'alamat'=>$this->input->post('alamat'),
'id_kabupatenkota'=>$this->input->post('id_kabupatenkota'),
'id_provinsi'=>$this->input->post('id_provinsi'),
'telepon'=>$this->input->post('telepon'),
'hp'=>$this->input->post('hp'),
'faksimili'=>$this->input->post('faksimili'),
'email'=>$this->input->post('email'),
'homepage'=>$this->input->post('homepage')

	);



	 	$edit=$this->lembaga_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

