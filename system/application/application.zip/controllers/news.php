<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
<?php

class news extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('news_model');
		
		    }


    public function index()
    {
	 $this->load->view('news/listnews');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from news')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->news_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_news'=>$obj->id_news,

			'judul'=>$obj->judul,
'isi_berita'=>$obj->isi,
'status'=>$obj->status

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'judul'=>$this->input->post('judul'),
'isi'=>$this->input->post('isi'),
'status'=>$this->input->post('status')
 
	 );
		$add=$this->news_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->news_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->news_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_news'=>$obj->id_news,

			'judul'=>$obj->judul,
'isi'=>$obj->isi,
'status'=>$obj->status

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$judul=trim($this->input->post('judul'));
$isi=trim($this->input->post('isi'));
$status=trim($this->input->post('status'));

   
	$id=$this->input->post('id_news');
	
	
	
	$Data=array(
	'judul'=>$this->input->post('judul'),
'isi'=>$this->input->post('isi'),
'status'=>$this->input->post('status')

	);



	 	$edit=$this->news_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

