<?php

class berita extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('berita_model');
		
		    }


    public function index()
    {
	 $this->load->view('berita/listberita');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from berita')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->berita_model->get_all_data($start,$limit,$q,$s);
			$status='null';	

        foreach ($query->result() as $obj)
        {
			if($obj->status==1)$status="<span style='color:blue'>Aktif</span>";
	if($obj->status==0)$status="<span style='color:red'>Tidak Aktif</span>";
	
	
            $arr[] =array(
			'id_berita'=>$obj->id_berita,

			'judul_berita'=>$obj->judul_berita,
'isi_berita'=>$obj->isi_berita,
'status'=>$status

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'judul_berita'=>$this->input->post('judul_berita'),
'isi_berita'=>$this->input->post('isi_berita'),
'status'=>$this->input->post('status')
 
	 );
		$add=$this->berita_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->berita_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->berita_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_berita'=>$obj->id_berita,

			'judul_berita'=>$obj->judul_berita,
'isi_berita'=>$obj->isi_berita,
'status'=>$obj->status

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$judul_berita=trim($this->input->post('judul_berita'));
$isi_berita=trim($this->input->post('isi_berita'));
$status=trim($this->input->post('status'));

   
	$id=$this->input->post('id_berita');
	
	
	
	$Data=array(
	'judul_berita'=>$this->input->post('judul_berita'),
'isi_berita'=>$this->input->post('isi_berita'),
'status'=>$this->input->post('status')

	);



	 	$edit=$this->berita_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

