<?php

class balasan extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('permohonan_model');
		
		    }


    public function index()
    {
	 $this->load->view('balasan/listbalasan');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from permohonan where type=1')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->permohonan_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
		if($obj->id_program!=0){
	$prog="<span style='color:green'>".$obj->kode_program." / ".$obj->nama_program."</span>";
	}
	else $prog="<span style='color:blue'>Lembaga</span>";
	if($obj->proses==1)$balas='<span style="color:blue"> Sudah kirim surat balasan</span>';
	else $balas='<span style="color:red">Belum kirim balasan</span>';
            $arr[] =array(
			'id_permohonan'=>$obj->id_permohonan,

			'no_permohonan'=>$obj->no_permohonan,
'tgl_terimasurat'=>str_replace("-","/",$obj->tgl_terimasurat),
'no_surat'=>$obj->no_surat,
'pemohon'=>$obj->pemohon,
'id_lembaga'=>$obj->nama_lembaga,
'id_program'=>$prog,
'permohonan'=>$obj->permohonan,
'proses'=>$balas,
'no_suratbalasan'=>$obj->no_suratbalasan,
'tgl_pengiriman'=>str_replace("-","/",$obj->tgl_pengiriman),
'tgl_balassurat'=>str_replace("-","/",$obj->tgl_balassurat),
'keterangan_balasan'=>$obj->keterangan_balasan,
'pernyataan'=>$obj->pernyataan,
'formulir'=>$obj->formulir,
'izin_operasional'=>$obj->izin_operasional,
'akta'=>$obj->akta,
'keterangan'=>$obj->keterangan

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'no_permohonan'=>$this->input->post('no_permohonan'),
'tgl_terimasurat'=>$this->input->post('tgl_terimasurat'),
'no_surat'=>$this->input->post('no_surat'),
'pemohon'=>$this->input->post('pemohon'),
'id_lembaga'=>$this->input->post('id_lembaga'),
'id_program'=>$this->input->post('id_program'),
'permohonan'=>$this->input->post('permohonan'),
'pernyataan'=>$this->input->post('pernyataan'),
'formulir'=>$this->input->post('formulir'),
'izin_operasional'=>$this->input->post('izin_operasional'),
'akta'=>$this->input->post('akta'),
'keterangan'=>$this->input->post('keterangan')
 
	 );
		$add=$this->permohonan_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->permohonan_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->permohonan_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_permohonan'=>$obj->id_permohonan,

			'no_permohonan'=>$obj->no_permohonan,
'tgl_terimasurat'=>$obj->tgl_terimasurat,
'no_surat'=>$obj->no_surat,
'pemohon'=>$obj->pemohon,
'tgl_balassurat'=>$obj->tgl_balassurat,
'id_program'=>$obj->id_program,
'id_lembaga'=>$obj->id_lembaga,
'permohonan'=>$obj->permohonan,
'pernyataan'=>$obj->pernyataan,
'formulir'=>$obj->formulir,
'izin_operasional'=>$obj->izin_operasional,
'akta'=>$obj->akta,
'proses'=>$obj->proses,
'no_suratbalasan'=>$obj->no_suratbalasan,
'tgl_pengiriman'=>$obj->tgl_pengiriman,
'keterangan_balasan'=>$obj->keterangan_balasan,

'keterangan'=>$obj->keterangan

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$no_permohonan=trim($this->input->post('no_permohonan'));
$tgl_terimasurat=trim($this->input->post('tgl_terimasurat'));
$no_surat=trim($this->input->post('no_surat'));
$pemohon=trim($this->input->post('pemohon'));

$id_lembaga=trim($this->input->post('id_lembaga'));
$permohonan=trim($this->input->post('permohonan'));
$pernyataan=trim($this->input->post('pernyataan'));
$formulir=trim($this->input->post('formulir'));
$izin_operasional=trim($this->input->post('izin_operasional'));
$akta=trim($this->input->post('akta'));
$keterangan=trim($this->input->post('keterangan'));

   
	$id=$this->input->post('id_permohonan');
	
	
	
	$Data=array(
	/*'no_permohonan'=>$this->input->post('no_permohonan'),
'tgl_terimasurat'=>$this->input->post('tgl_terimasurat'),
'no_surat'=>$this->input->post('no_surat'),
'pemohon'=>$this->input->post('pemohon'),
'id_program'=>$this->input->post('id_program'),
'id_lembaga'=>$this->input->post('id_lembaga'),
'permohonan'=>$this->input->post('permohonan'),
'pernyataan'=>$this->input->post('pernyataan'),
'formulir'=>$this->input->post('formulir'),
'izin_operasional'=>$this->input->post('izin_operasional'),
'akta'=>$this->input->post('akta'),
'keterangan'=>$this->input->post('keterangan')
*/
'proses'=>$this->input->post('proses'),
'tgl_balassurat'=>$this->input->post('tgl_balassurat'),
'no_suratbalasan'=>$this->input->post('no_suratbalasan'),
'tgl_pengiriman'=>$this->input->post('tgl_pengiriman'),
'keterangan_balasan'=>$this->input->post('keterangan_balasan')
	);



	 	$edit=$this->permohonan_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

