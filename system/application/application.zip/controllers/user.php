<?php

class user extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('user_model');
		$this->load->library('session');
		
		    }


    public function index()
    {
	 $this->load->view('user/listuser');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from user')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->user_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_user'=>$obj->id_user,
            'last_login'=>$obj->last_login,
			'id_karyawan'=>$obj->nip." / ".$obj->nama,
			'username'=>$obj->username,
			'ip'=>$obj->ip,
            'role'=>$obj->role

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	$master=$this->input->post('master');
	$berkas1=$this->input->post('berkas1');
	$pendaftaran=$this->input->post('pendaftaran');
	$lembaga=$this->input->post('lembaga');
	$asesor=$this->input->post('asesor');
	$balas=$this->input->post('balas');
	$akreditasi=$this->input->post('akreditasi');
	$suratmasuk=$this->input->post('suratmasuk');
	
if($master!="")$master=1;
	else $master=0;
	if($berkas1!="")$berkas1=1;
	else $berkas1=0;
	if($pendaftaran!="")$pendaftaran=1;
	else $pendaftaran=0;
	if($lembaga!="")$lembaga=1;
	else $lembaga=0;
	if($asesor!="")$asesor=1;
	else $asesor=0;	
	if($balas!="")$balas=1;
	else $balas=0;
	if($akreditasi!="")$akreditasi=1;
	else $akreditasi=0;	
	if($suratmasuk!="")$suratmasuk=1;
	else $suratmasuk=0;	
	
	$role=$master.";".$berkas1.";".$balas.";".$lembaga.";".$asesor.";".$pendaftaran.";".$akreditasi.";".$suratmasuk;
	$username=$this->input->post('username');
	$password=md5($this->input->post('password'));
	$Data=array(
	'username'=>$username,
	'password'=>$password,
	'id_karyawan'=>$this->input->post('id_karyawan'),
     'role'=>$role
 
	 );
		$add=$this->user_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->user_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->user_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
		
		$role=explode(";",$obj->role);
            $arr[] = array(
			'id_user'=>$obj->id_user,
			'username'=>$obj->username,
			'master'=>$role[0],
			'berkas1'=>$role[1],
			'pendaftaran'=>$role[5],
			'akreditasi'=>$role[6],
			'lembaga'=>$role[3],
			'asesor'=>$role[4],
			'balas'=>$role[2],
			'suratmasuk'=>$role[7],
			'id_karyawan'=>$obj->id_karyawan,
'role'=>$obj->role

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$id_karyawan=trim($this->input->post('id_karyawan'));
$role=trim($this->input->post('role'));

   
	$id=$this->input->post('id_user');
	$master=$this->input->post('master');
	$berkas1=$this->input->post('berkas1');
	$pendaftaran=$this->input->post('pendaftaran');
	$lembaga=$this->input->post('lembaga');
	$asesor=$this->input->post('asesor');
	$balas=$this->input->post('balas');
	$akreditasi=$this->input->post('akreditasi');
	$suratmasuk=$this->input->post('suratmasuk');
	if($master!="")$master=1;
	else $master=0;
	if($berkas1!="")$berkas1=1;
	else $berkas1=0;
	if($pendaftaran!="")$pendaftaran=1;
	else $pendaftaran=0;
	if($lembaga!="")$lembaga=1;
	else $lembaga=0;
	if($balas!="")$balas=1;
	else $balas=0;	
	if($asesor!="")$asesor=1;
	else $asesor=0;	
	if($akreditasi!="")$akreditasi=1;
	else $akreditasi=0;	
	if($suratmasuk!="")$suratmasuk=1;
	else $suratmasuk=0;	
	
	$role=$master.";".$berkas1.";".$balas.";".$lembaga.";".$asesor.";".$pendaftaran.";".$akreditasi.";".$suratmasuk;
	$username=$this->input->post('username');
	$password=md5($this->input->post('password'));
	
	if($this->input->post('password')!=""){
	$Data=array(
	'username'=>$username,
	'password'=>$password,
	'id_karyawan'=>$this->input->post('id_karyawan'),
    'role'=>$role
	);
	}
	else {
	$Data=array(
	'username'=>$username,
	'id_karyawan'=>$this->input->post('id_karyawan'),
    'role'=>$role
	);
	
	}



	 	$edit=$this->user_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	
	public function editpass(){
	$this->load->view('user/editPass');
	}
	
	
	function saveEditPass(){
	if($this->session->userdata('pass')!=md5($this->input->post('oldpass'))){
	echo '{failed:true}';
	}
	else{
	if($this->input->post('newpass')==$this->input->post('confirm')){
	$user=array('password'=>md5($this->input->post('newpass')));
	$edit=$this->user_model->edit($user,$this->session->userdata('id_user'));
	 echo '{success:true}';
	}
	else echo '{failed:true}';
	 }
	}
	}
	

