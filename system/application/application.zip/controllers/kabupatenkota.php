<?php

class kabupatenkota extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('kabupatenkota_model');
		
		    }


    public function index()
    {
	 $this->load->view('kabupatenkota/listkabupatenkota');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from kabupatenkota')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->kabupatenkota_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_kabupatenkota'=>$obj->id_kabupatenkota,

			'kode'=>$obj->kode,
'kabupaten_kota'=>$obj->kabupaten_kota

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'kode'=>$this->input->post('kode'),
'kabupaten_kota'=>$this->input->post('kabupaten_kota')
 
	 );
		$add=$this->kabupatenkota_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->kabupatenkota_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->kabupatenkota_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_kabupatenkota'=>$obj->id_kabupatenkota,

			'kode'=>$obj->kode,
'kabupaten_kota'=>$obj->kabupaten_kota

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$kode=trim($this->input->post('kode'));
$kabupaten_kota=trim($this->input->post('kabupaten_kota'));

   
	$id=$this->input->post('id_kabupatenkota');
	
	
	
	$Data=array(
	'kode'=>$this->input->post('kode'),
'kabupaten_kota'=>$this->input->post('kabupaten_kota')

	);



	 	$edit=$this->kabupatenkota_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

