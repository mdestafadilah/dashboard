<?php

class karyawan extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('karyawan_model');
		
		    }


    public function index()
    {
	 $this->load->view('karyawan/listkaryawan');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from karyawan')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->karyawan_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_karyawan'=>$obj->id_karyawan,

			'nama'=>$obj->nama,
'nip'=>$obj->nip,
'alamat'=>$obj->alamat,
'telepon'=>$obj->telepon,
'tempat'=>$obj->tempat,
'tanggal_lahir'=>str_replace("-","/",$obj->tanggal_lahir),
'pendidikan_terakhir'=>$obj->pendidikan_terakhir,
'email'=>$obj->email,
'foto'=>$obj->foto

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'nama'=>$this->input->post('nama'),
'nip'=>$this->input->post('nip'),
'alamat'=>$this->input->post('alamat'),
'telepon'=>$this->input->post('telepon'),
'tempat'=>$this->input->post('tempat'),
'tanggal_lahir'=>$this->input->post('tanggal_lahir'),
'pendidikan_terakhir'=>$this->input->post('pendidikan_terakhir'),
'email'=>$this->input->post('email'),
'foto'=>$this->input->post('foto')
 
	 );
		$add=$this->karyawan_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->karyawan_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->karyawan_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_karyawan'=>$obj->id_karyawan,

			'nama'=>$obj->nama,
'nip'=>$obj->nip,
'alamat'=>$obj->alamat,
'telepon'=>$obj->telepon,
'tempat'=>$obj->tempat,
'tanggal_lahir'=>$obj->tanggal_lahir,
'pendidikan_terakhir'=>$obj->pendidikan_terakhir,
'email'=>$obj->email,
'foto'=>$obj->foto

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$nama=trim($this->input->post('nama'));
$nip=trim($this->input->post('nip'));
$alamat=trim($this->input->post('alamat'));
$telepon=trim($this->input->post('telepon'));
$tempat=trim($this->input->post('tempat'));
$tanggal_lahir=trim($this->input->post('tanggal_lahir'));
$pendidikan_terakhir=trim($this->input->post('pendidikan_terakhir'));
$email=trim($this->input->post('email'));
$foto=trim($this->input->post('foto'));

   
	$id=$this->input->post('id_karyawan');
	
	
	
	$Data=array(
	'nama'=>$this->input->post('nama'),
'nip'=>$this->input->post('nip'),
'alamat'=>$this->input->post('alamat'),
'telepon'=>$this->input->post('telepon'),
'tempat'=>$this->input->post('tempat'),
'tanggal_lahir'=>$this->input->post('tanggal_lahir'),
'pendidikan_terakhir'=>$this->input->post('pendidikan_terakhir'),
'email'=>$this->input->post('email'),
'foto'=>$this->input->post('foto')

	);



	 	$edit=$this->karyawan_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

