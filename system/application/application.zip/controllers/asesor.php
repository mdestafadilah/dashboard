<?php

class asesor extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('asesor_model');
		
		    }


    public function index()
    {
	 $this->load->view('asesor/listasesor');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from asesor')->row();
        $arr = array();
		/*if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->asesor_model->get_all_data($start,$limit,$q,$s);
		*/
		if (isset($_POST['task'])){
		if($_POST['task']=='cari'){
		if($_POST['status']=="")$st=3;
		else $st=$_POST['status'];
		if($_POST['nama']=="")$nm=0;
		else $nm=$_POST['nama'];
		$q=$nm;$s=1;;
		}
		if($_POST['task']=='data'){
		$q='';$s=0;$st=3;
		}
		}
		else {$q='';$s=0;$st=3;}
		$query=$this->asesor_model->get_all_data($start,$limit,$q,$s,$st);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	$jk="";
	if($obj->jenis_kelamin=='L')$jk="Laki-laki";
	else if($obj->jenis_kelamin=='P')$jk="Perempuan";
	if($obj->status==1)$status="<span style='color:blue'>Aktif</span>";
	if($obj->status==0)$status="<span style='color:red'>Tidak Aktif</span>";

            $arr[] =array(
			'id_asesor'=>$obj->id_asesor,

			'no_urut_asesor'=>$obj->no_urut_asesor,
'nama'=>$obj->nama,
'angkatan'=>$obj->angkatan,
'bulan'=>$obj->bulan,
'tahun'=>$obj->tahun,
'id_program'=>$obj->kode_program,
'jenis_kelamin'=>$jk,
'alamat_surat_menyurat'=>$obj->alamat_surat_menyurat,
'alamat_kantor'=>$obj->alamat_kantor,
'email'=>$obj->email,
'telepon'=>$obj->telepon,
'id_kabupatenkota'=>$obj->kabupaten_kota,
'id_provinsi'=>$obj->provinsi,
'id_jabatan'=>$obj->jabatan,
'status'=>$status,
'angkatan_asesor'=>$obj->angkatan_asesor,
'no_sertifikat'=>$obj->no_sertifikat

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'no_urut_asesor'=>$this->input->post('no_urut_asesor'),
'nama'=>$this->input->post('nama'),
'angkatan'=>$this->input->post('angkatan'),
'bulan'=>$this->input->post('bulan'),
'tahun'=>$this->input->post('tahun'),
'id_program'=>$this->input->post('id_program'),
'jenis_kelamin'=>$this->input->post('jenis_kelamin'),
'alamat_surat_menyurat'=>$this->input->post('alamat_surat_menyurat'),
'alamat_kantor'=>$this->input->post('alamat_kantor'),
'email'=>$this->input->post('email'),
'telepon'=>$this->input->post('telepon'),
'id_kabupatenkota'=>$this->input->post('id_kabupatenkota'),
'id_provinsi'=>$this->input->post('id_provinsi'),
'id_jabatan'=>$this->input->post('id_jabatan'),
'status'=>$this->input->post('status'),
'angkatan_asesor'=>$this->input->post('angkatan_asesor'),
'no_sertifikat'=>$this->input->post('no_sertifikat')
 
	 );
		$add=$this->asesor_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->asesor_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->asesor_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_asesor'=>$obj->id_asesor,

			'no_urut_asesor'=>$obj->no_urut_asesor,
'nama'=>$obj->nama,
'angkatan'=>$obj->angkatan,
'bulan'=>$obj->bulan,
'tahun'=>$obj->tahun,
'id_program'=>$obj->id_program,
'jenis_kelamin'=>$obj->jenis_kelamin,
'alamat_surat_menyurat'=>$obj->alamat_surat_menyurat,
'alamat_kantor'=>$obj->alamat_kantor,
'email'=>$obj->email,
'telepon'=>$obj->telepon,
'id_kabupatenkota'=>$obj->id_kabupatenkota,
'id_provinsi'=>$obj->id_provinsi,
'id_jabatan'=>$obj->id_jabatan,
'status'=>$obj->status,
'angkatan_asesor'=>$obj->angkatan_asesor,
'no_sertifikat'=>$obj->no_sertifikat

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$no_urut_asesor=trim($this->input->post('no_urut_asesor'));
$nama=trim($this->input->post('nama'));
$angkatan=trim($this->input->post('angkatan'));
$bulan=trim($this->input->post('bulan'));
$tahun=trim($this->input->post('tahun'));
$id_program=trim($this->input->post('id_program'));
$jenis_kelamin=trim($this->input->post('jenis_kelamin'));
$alamat_surat_menyurat=trim($this->input->post('alamat_surat_menyurat'));
$alamat_kantor=trim($this->input->post('alamat_kantor'));
$email=trim($this->input->post('email'));
$telepon=trim($this->input->post('telepon'));
$id_kabupatenkota=trim($this->input->post('id_kabupatenkota'));
$id_provinsi=trim($this->input->post('id_provinsi'));
$id_jabatan=trim($this->input->post('id_jabatan'));
$status=trim($this->input->post('status'));
$angkatan_asesor=trim($this->input->post('angkatan_asesor'));
$no_sertifikat=trim($this->input->post('no_sertifikat'));

   
	$id=$this->input->post('id_asesor');
	
	
	
	$Data=array(
	'no_urut_asesor'=>$this->input->post('no_urut_asesor'),
'nama'=>$this->input->post('nama'),
'angkatan'=>$this->input->post('angkatan'),
'bulan'=>$this->input->post('bulan'),
'tahun'=>$this->input->post('tahun'),
'id_program'=>$this->input->post('id_program'),
'jenis_kelamin'=>$this->input->post('jenis_kelamin'),
'alamat_surat_menyurat'=>$this->input->post('alamat_surat_menyurat'),
'alamat_kantor'=>$this->input->post('alamat_kantor'),
'email'=>$this->input->post('email'),
'telepon'=>$this->input->post('telepon'),
'id_kabupatenkota'=>$this->input->post('id_kabupatenkota'),
'id_provinsi'=>$this->input->post('id_provinsi'),
'id_jabatan'=>$this->input->post('id_jabatan'),
'status'=>$this->input->post('status'),
'angkatan_asesor'=>$this->input->post('angkatan_asesor'),
'no_sertifikat'=>$this->input->post('no_sertifikat')

	);



	 	$edit=$this->asesor_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

