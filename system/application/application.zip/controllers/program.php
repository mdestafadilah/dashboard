<?php

class program extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('program_model');
		
		    }


    public function index()
    {
	 $this->load->view('program/listprogram');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from program')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->program_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_program'=>$obj->id_program,

			'kode_program'=>$obj->kode_program,
'nama_program'=>$obj->nama_program,
'description'=>$obj->description

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'kode_program'=>$this->input->post('kode_program'),
'nama_program'=>$this->input->post('nama_program'),
'description'=>$this->input->post('description')
 
	 );
		$add=$this->program_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->program_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->program_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_program'=>$obj->id_program,

			'kode_program'=>$obj->kode_program,
'nama_program'=>$obj->nama_program,
'description'=>$obj->description

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
$kode_program=trim($this->input->post('kode_program'));
$nama_program=trim($this->input->post('nama_program'));
$description=trim($this->input->post('description'));

   
	$id=$this->input->post('id_program');
	
	
	
	$Data=array(
	'kode_program'=>$this->input->post('kode_program'),
'nama_program'=>$this->input->post('nama_program'),
'description'=>$this->input->post('description')

	);



	 	$edit=$this->program_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	
