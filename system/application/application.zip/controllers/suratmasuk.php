<?php

class suratmasuk extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('suratmasuk_model');
		
		    }


    public function index()
    {
	 $this->load->view('surat/listsuratmasuk');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from permohonan')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->suratmasuk_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	if($obj->id_program!=0){
	$prog="<span style='color:green'>".$obj->kode_program." / ".$obj->nama_program."</span>";
	}
	else $prog="<span style='color:blue'>Lembaga</span>";
	if($obj->type==1)$type="<span style='color:blue'>Surat akreditas</span>";
	if($obj->type==0)$type="<span style='color:red'>Bukan surat akreditasi</span>";
            $arr[] =array(
			'id_permohonan'=>$obj->id_permohonan,
            'perihal'=>$obj->perihal,
			//'no_permohonan'=>$obj->no_permohonan,
'tgl_terimasurat'=>str_replace("-","/",$obj->tgl_terimasurat),
'no_surat'=>$obj->no_surat,
'pemohon'=>$obj->pemohon,
'kode'=>$obj->kode,
'tandatangan'=>$obj->tandatangan,

'id_lembaga'=>$obj->nama_lembaga,
'id_program'=>$prog,
'type'=>$type,

/*'permohonan'=>$obj->permohonan,
'pernyataan'=>$obj->pernyataan,
'formulir'=>$obj->formulir,
'izin_operasional'=>$obj->izin_operasional,
'akta'=>$obj->akta,*/
'keterangan'=>$obj->keterangan

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	if($this->input->post('type')==1){
$rand=rand(1000000000,9999999999);
$rand2=rand(1000,9999);
$kode=$rand."".$rand2;
}
else{
$kode=0;
}

	$Data=array(
//'no_permohonan'=>$this->input->post('no_permohonan'),
'tgl_terimasurat'=>$this->input->post('tgl_terimasurat'),
'tandatangan'=>$this->input->post('tandatangan'),
'tgl_balassurat'=>$this->input->post('tgl_terimasurat'),
'tgl_prosespermohonan'=>$this->input->post('tgl_terimasurat'),
'tgl_pendaftaran'=>$this->input->post('tgl_terimasurat'),
'no_surat'=>$this->input->post('no_surat'),
'pemohon'=>$this->input->post('pemohon'),
'perihal'=>$this->input->post('perihal'),
'id_lembaga'=>$this->input->post('id_lembaga'),
'id_program'=>$this->input->post('id_program'),
'type'=>$this->input->post('type'),
'kode'=>$kode,

/*'permohonan'=>$this->input->post('permohonan'),
'pernyataan'=>$this->input->post('pernyataan'),
'formulir'=>$this->input->post('formulir'),
'izin_operasional'=>$this->input->post('izin_operasional'),
'akta'=>$this->input->post('akta'),*/
'keterangan'=>$this->input->post('keterangan')
 
	 );
		$add=$this->suratmasuk_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->permohonan_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->suratmasuk_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_permohonan'=>$obj->id_permohonan,

			//'no_permohonan'=>$obj->no_permohonan,
'tgl_terimasurat'=>$obj->tgl_terimasurat,
'no_surat'=>$obj->no_surat,
'perihal'=>$obj->perihal,
'tandatangan'=>$obj->tandatangan,
'kode'=>$obj->kode,
'pemohon'=>$obj->pemohon,
'id_program'=>$obj->id_program,
'id_lembaga'=>$obj->id_lembaga,
'type'=>$obj->type,
/*'permohonan'=>$obj->permohonan,
'pernyataan'=>$obj->pernyataan,
'formulir'=>$obj->formulir,
'izin_operasional'=>$obj->izin_operasional,
'akta'=>$obj->akta,*/
'keterangan'=>$obj->keterangan

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
//$no_permohonan=trim($this->input->post('no_permohonan'));
$tgl_terimasurat=trim($this->input->post('tgl_terimasurat'));
$no_surat=trim($this->input->post('no_surat'));
$pemohon=trim($this->input->post('pemohon'));

$id_lembaga=trim($this->input->post('id_lembaga'));
/*$permohonan=trim($this->input->post('permohonan'));
$pernyataan=trim($this->input->post('pernyataan'));
$formulir=trim($this->input->post('formulir'));
$izin_operasional=trim($this->input->post('izin_operasional'));
$akta=trim($this->input->post('akta'));*/
$keterangan=trim($this->input->post('keterangan'));

   
	$id=$this->input->post('id_permohonan');
	
	
	
	$Data=array(
	//'no_permohonan'=>$this->input->post('no_permohonan'),
'tgl_terimasurat'=>$this->input->post('tgl_terimasurat'),
'no_surat'=>$this->input->post('no_surat'),
'pemohon'=>$this->input->post('pemohon'),
'kode'=>$this->input->post('kode'),
'perihal'=>$this->input->post('perihal'),
'id_program'=>$this->input->post('id_program'),
'id_lembaga'=>$this->input->post('id_lembaga'),
'tandatangan'=>$this->input->post('tandatangan'),
'type'=>$this->input->post('type'),
/*'permohonan'=>$this->input->post('permohonan'),
'pernyataan'=>$this->input->post('pernyataan'),
'formulir'=>$this->input->post('formulir'),
'izin_operasional'=>$this->input->post('izin_operasional'),
'akta'=>$this->input->post('akta'),*/
'keterangan'=>$this->input->post('keterangan')

	);



	 	$edit=$this->suratmasuk_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

