<?php

class provinsi extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('provinsi_model');
		
		    }


    public function index()
    {
	 $this->load->view('provinsi/listprovinsi');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from provinsi')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->provinsi_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_provinsi'=>$obj->id_provinsi,

			'kode'=>$obj->kode,
'provinsi'=>$obj->provinsi

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'kode'=>$this->input->post('kode'),
'provinsi'=>$this->input->post('provinsi')
 
	 );
		$add=$this->provinsi_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->provinsi_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->provinsi_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_provinsi'=>$obj->id_provinsi,

			'kode'=>$obj->kode,
'provinsi'=>$obj->provinsi

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$kode=trim($this->input->post('kode'));
$provinsi=trim($this->input->post('provinsi'));

   
	$id=$this->input->post('id_provinsi');
	
	
	
	$Data=array(
	'kode'=>$this->input->post('kode'),
'provinsi'=>$this->input->post('provinsi')

	);



	 	$edit=$this->provinsi_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

