<?php

class shoutbox extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('shoutbox_model');
		
		    }


    public function index()
    {
	 $this->load->view('shoutbox/listshoutbox');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from shoutbox')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->shoutbox_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	if($obj->status==1)$status="<span style='color:blue'>Aktif</span>";
	if($obj->status==0)$status="<span style='color:red'>Tidak Aktif</span>";
	
            $arr[] =array(
			'id_shoutbox'=>$obj->id_shoutbox,

			'nama_pengunjung'=>$obj->nama_pengunjung,
'email_pengunjung'=>$obj->email_pengunjung,
'komentar_pengunjung'=>$obj->komentar_pengunjung,
'status'=>$status

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'nama_pengunjung'=>$this->input->post('nama_pengunjung'),
'email_pengunjung'=>$this->input->post('email_pengunjung'),
'komentar_pengunjung'=>$this->input->post('komentar_pengunjung'),
'status'=>$this->input->post('status')
 
	 );
		$add=$this->shoutbox_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->shoutbox_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->shoutbox_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_shoutbox'=>$obj->id_shoutbox,

			'nama_pengunjung'=>$obj->nama_pengunjung,
'email_pengunjung'=>$obj->email_pengunjung,
'komentar_pengunjung'=>$obj->komentar_pengunjung,
'status'=>$obj->status

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$nama_pengunjung=trim($this->input->post('nama_pengunjung'));
$email_pengunjung=trim($this->input->post('email_pengunjung'));
$komentar_pengunjung=trim($this->input->post('komentar_pengunjung'));
$status=trim($this->input->post('status'));

   
	$id=$this->input->post('id_shoutbox');
	
	
	
	$Data=array(
	'nama_pengunjung'=>$this->input->post('nama_pengunjung'),
'email_pengunjung'=>$this->input->post('email_pengunjung'),
'komentar_pengunjung'=>$this->input->post('komentar_pengunjung'),
'status'=>$this->input->post('status')

	);



	 	$edit=$this->shoutbox_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

