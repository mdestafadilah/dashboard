<?php

class lamaranasesoruser extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('lamaranasesoruser_model');
		
		    }


    public function index()
    {
	 $this->load->view('lamaranasesoruser/listlamaranasesor');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from lamaranasesor')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->lamaranasesoruser_model->get_all_data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	if($obj->status==1)$status="<span style='color:blue'>Disetujui</span>";
	if($obj->status==0)$status="<span style='color:red'>Menunggu</span>";
	if($obj->status==2)$status="<span style='color:red'>Tidak disetujui</span>";
	
            $arr[] =array(
			'id_lamaranasesor'=>$obj->id_lamaranasesor,

			'nama_pelamar'=>$obj->nama_pelamar,
'no_pelamar'=>$obj->no_pelamar,
'email_pelamar'=>$obj->email_pelamar,
'alamat_pelamar'=>$obj->alamat_pelamar,
'cv_pelamar'=>$obj->cv_pelamar,
'keterangan'=>$obj->keterangan,
'tgl_daftar'=>$obj->tgl_daftar,
'status'=>$status

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	$acak = rand(0000,9999);
		$file=$_FILES['cv_pelamar']['name'];
		$file=ereg_replace("-","_",$file);
		$file=ereg_replace("'","_",$file);
		$file=explode(".",ereg_replace(",","_",$file));
		$nama_file=substr($file[0],0,15).$acak.".".$file[1];
		move_uploaded_file ($_FILES['cv_pelamar']['tmp_name'],"assets/upload/lamaran/".$nama_file);
	$Data=array(
	'nama_pelamar'=>$this->input->post('nama_pelamar'),
'no_pelamar'=>$this->input->post('no_pelamar'),
'email_pelamar'=>$this->input->post('email_pelamar'),
'alamat_pelamar'=>$this->input->post('alamat_pelamar'),
'cv_pelamar'=>$nama_file
 
	 );
		$add=$this->lamaranasesoruser_model->add_data($Data);
		 echo '{success:true}';
		
		}
		
  
	
	
	
	
	}
	

