<?php

class Home extends Controller {

    public function  __construct()
    {
        parent::Controller();
	   $this->load->helper('url');
		$this->load->library('session');
		
		if(!$this->session->userdata('user')||!$this->session->userdata('id_user')){redirect('login/', 'refresh');}
    }
	   

    public function index()
    {
//	$data['nmop']=$this->session->userdata('usrnm');
	//	$data['jbtn']=$this->session->userdata('jbtn');
        
		$this->load->view('index');
		 $this->load->view('menu');
    }
	public function karyawan(){
	   $this->load->view('frame/karyawan');
	
	}
	public function editpass(){
	   $this->load->view('frame/editpass');
	
	}
	public function suratmasuk(){
	   $this->load->view('frame/suratmasuk');
	
	}
	public function program(){
	   $this->load->view('frame/program');
	
	}
	public function komentar(){
	   $this->load->view('frame/komentar');
	
	}
	public function provinsi(){
	   $this->load->view('frame/provinsi');
	
	}
		public function news(){
	   $this->load->view('frame/news');
	}

	public function kabupatenkota(){
	   $this->load->view('frame/kabupatenkota');
	
	}
	public function surat(){
	   $this->load->view('frame/surat');
	
	}
		public function lembaga(){
	   $this->load->view('frame/lembaga');
	
	}
	public function asesor(){
	   $this->load->view('frame/asesor');
	
	}
		public function user(){
	   $this->load->view('frame/user');
	
	}
		public function akreditasi(){
	   $this->load->view('frame/akreditasi');
	
	}
		public function jabatan(){
	   $this->load->view('frame/jabatan');
	
	}
		public function permohonan(){
	   $this->load->view('frame/permohonan');
	
	}
		public function balasan(){
	   $this->load->view('frame/balasan');
	
	}
		public function pendaftaran(){
	   $this->load->view('frame/pendaftaran');
	
	}
		public function lamaranasesor(){
	   $this->load->view('frame/lamaranasesor');
	
	}
	
   
}

?>
