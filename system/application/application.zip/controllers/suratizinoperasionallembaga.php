<?php

class suratizinoperasionallembaga extends Controller {

    public function  __construct()
    {
        parent::Controller();
		$this->load->helper('url');
		$this->load->model('suratizinoperasionallembaga_model');
		
		    }


    public function index()
    {
	 $this->load->view('suratizinoperasionallembaga/listsuratizinoperasionallembaga');
	}
	
	
	 public function get_all_data()
    {
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : 0;
		$limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100;

           
      
        $results = $this->db->query('select count(*) as total from suratizinoperasionallembaga')->row();
        $arr = array();
		if (isset($_POST['query'])){
		$q=$_POST['query'];$s=1;}
		else {$q='';$s=0;}
		$query=$this->suratizinoperasionallembaga_model->get_all_Data($start,$limit,$q,$s);
			$status='null';	
        foreach ($query->result() as $obj)
        {
	
	
            $arr[] =array(
			'id_suratizinoperasionallembaga'=>$obj->id_suratizinoperasionallembaga,

			'nomor'=>$obj->nomor,
'tanggal'=>$obj->tanggal,
'diterbitkan_oleh'=>$obj->diterbitkan_oleh,
'masa_berlaku'=>$obj->masa_berlaku

			);
        }
        echo '{success:true,results:'.$results->total .
                ',rows:'.json_encode($arr).'}';
    }
	
	public function add(){
	
	
	$Data=array(
	'nomor'=>$this->input->post('nomor'),
'tanggal'=>$this->input->post('tanggal'),
'diterbitkan_oleh'=>$this->input->post('diterbitkan_oleh'),
'masa_berlaku'=>$this->input->post('masa_berlaku')
 
	 );
		$add=$this->suratizinoperasionallembaga_model->add_data($Data);
		 echo '{success:true}';
		
		}
		public function delete()
    {
        $records = explode(';', $_POST['postdata']);
        foreach($records as $id)
        {
                   $query=$this->suratizinoperasionallembaga_model->delete_data($id);
        }
    }
	
	public function getData($id){
	
	$query=$this->suratizinoperasionallembaga_model->getData($id);
	$arr=array();
	   foreach ($query->result() as $obj)
        {
	
            $arr[] = array(
			'id_suratizinoperasionallembaga'=>$obj->id_suratizinoperasionallembaga,

			'nomor'=>$obj->nomor,
'tanggal'=>$obj->tanggal,
'diterbitkan_oleh'=>$obj->diterbitkan_oleh,
'masa_berlaku'=>$obj->masa_berlaku

			);
        }
	  echo '{rows:1,results:'.json_encode($arr).'}';	
	
	}
	
	function editData(){
	
	$nomor=trim($this->input->post('nomor'));
$tanggal=trim($this->input->post('tanggal'));
$diterbitkan_oleh=trim($this->input->post('diterbitkan_oleh'));
$masa_berlaku=trim($this->input->post('masa_berlaku'));

   
	$id=$this->input->post('id_suratizinoperasionallembaga');
	
	
	
	$Data=array(
	'nomor'=>$this->input->post('nomor'),
'tanggal'=>$this->input->post('tanggal'),
'diterbitkan_oleh'=>$this->input->post('diterbitkan_oleh'),
'masa_berlaku'=>$this->input->post('masa_berlaku')

	);



	 	$edit=$this->suratizinoperasionallembaga_model->update_data($Data,$id);
		 echo '{success:true}';
	}
	}
	

