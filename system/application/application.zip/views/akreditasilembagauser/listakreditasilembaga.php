<html>
<head>
    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/js/ext/resources/css/ext-all.css'/>

    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/adapter/ext/ext-base.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/ext-all.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/FileUploadField.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/searchfield.js'></script>
     
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/expander.js'></script>
	    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/css/fileuploadfield.css'/>
		 <link rel='stylesheet' type='text/css' href='<?=base_url()?>assets/js/ext/resources/css/xtheme-gray.css' />
    <script type='text/javascript'>
    var BASE_URL = '<?php echo base_url(); ?>' + '/';
    var BASE_PATH = '<?php echo base_url(); ?>';
    var BASE_ICONS = BASE_PATH + 'assets/icons/';
    Ext.onReady(function() {
        var listData = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                fields: [
                   'id_akreditasilembaga','id_lembaga','status','tgl_akreditasi','id_program','asesor1','asesor2','kabupaten_kota','provinsi'
                ],
                root: 'rows', totalProperty: 'results'
            }),
            proxy: new Ext.data.HttpProxy({
                url: BASE_URL + 'akreditasilembagauser/get_all_data',
                method: 'POST'
            })
        });
		 var excelData = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                fields: [
                   'id_akreditasilembaga','id_lembaga','status','tgl_akreditasi','id_program','asesor1','asesor2','kabupaten_kota','provinsi'
                ],
                root: 'rows', totalProperty: 'results'
            }),
            proxy: new Ext.data.HttpProxy({
                url: BASE_URL + 'akreditasilembagauser/get_all_data_print',
                method: 'POST'
            })
        });

        var searchData = new Ext.app.SearchField({
            store: listData,
            params: {start: 0, limit: 100},
            width: 180,
            id: 'fieldUsersSearch'
        });
	

	
	
        var tbData = new Ext.Toolbar({
            items:[/*(, '-', {
            text: 'Search',
            tooltip: 'Advanced Search',
            handler: startAdvancedSearch,  // search function
             icon: BASE_ICONS + 'search.png',               // we'll need to add this to our css
          }*/
		/*, '->', searchData*/]
        });

        
                   
        

var provinsi;
 provinsi = new Ext.form.ComboBox({
         transform:'provinsisearch',
		hiddenName : 'id_provinsi',
        fieldLabel:'Provinsi', 
        typeAhead: true,
		mode:'local',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Provinsi',
        selectOnFocus:true,
		id:'id_provinsi5',
		anchor: '95%',	
		name: 'id_provinsi'
            });


  var nama; var status; var pencarianform;var pencarianWindow;
  
  nama = new Ext.form.TextField({
          fieldLabel: 'Nama Lembaga',
          maxLength: 20,
          anchor : '95%',
          maskRe: /([a-zA-Z0-9\s]+)$/
            });
			
			      status = new Ext.form.ComboBox({
         fieldLabel: 'status',
         store:new Ext.data.SimpleStore({
          fields:['statusValue', 'statusName'],
          data: [['1','Terakreditasi'],['0','Belum terakreditasi'],['0','Ditunda']]
          }),
         mode: 'local',
         displayField: 'statusName',
		 emptyText:'status',
         valueField: 'statusValue',
         anchor:'95%',
         triggerAction: 'all'
            });
			
			 
  pencarianform = new Ext.FormPanel({
       labelAlign: 'top',
	   applyTo:'searching',
	    frame:true,
       bodyStyle: 'padding: 5px;',
       width: 600,
       items: [{
         layout: 'form',
         border: false,
		 id:'advancedsearch',
         items: [
		{
		  layout:'column',
            items:[
			{
                columnWidth:.3,
                layout: 'form',
              items: [nama]
            },{
                columnWidth:.3,
                layout: 'form',
                items: [status]
            },{
                columnWidth:.4,
                layout: 'form',
                items: [provinsi]
		 }
		 ]
		 }]
		 ,
         buttons: [{
               text: 'Cari Data ',
               handler: listSearch
             },{
               text: 'Print Data Excel ',
               handler: printData
             },{
               text: 'Semua Data',
               handler: resetSearch
             }]
         }]
     });
 /*pencarianWindow = new Ext.Window({
         title: 'Cari data akreditasi',
         closable:true,
         width: 300,
         height: 300,
         plain:true,
         layout: 'fit',
         items: pencarianform
     });*/
	  function listSearch(){
         // render according to a SQL date format.
   /*      var startDate = "";
         var endDate = "";
         if(SearchEnteringItem.getValue() != "") {
            startDate = SearchEnteringItem.getValue().format('Y-m-d');
         }
         if(SearchLeavingItem.getValue() != "") {
            endDate = SearchLeavingItem.getValue().format('Y-m-d');
         }
     */    
         // change the store parameters
    	    listData.baseParams = {
   			task: 'cari',
   			nama: nama.getValue(),
			status: status.getValue(),
			provinsi: provinsi.getValue()/*,
            lastname : SearchLastNameItem.getValue(),
            party : SearchPartyItem.getValue(),
            enteringoffice : startDate,
            leavingoffice : endDate*/
   		};
         // Cause the datastore to do another query : 
   		listData.reload();
     }
	 function printData(){
	 var n=0;
	 if(nama.getValue()=="")n=0;
	 else n=nama.getValue();
	  if(status.getValue()=="")s=3;
	 else s=status.getValue();
	 if(provinsi.getValue()=="")p=0;
	 else p=provinsi.getValue();
	  // location='<?=base_url()?>/assets/excel.php?n='+n;
	   location='akreditasilembagauser/get_all_data_print/'+n+'/'+s+'/'+p;
   			/*nama: ,
			status: status.getValue(),
			printdata:1,
			provinsi: provinsi.getValue()/*,
            lastname : SearchLastNameItem.getValue(),
            party : SearchPartyItem.getValue(),
            enteringoffice : startDate,
            leavingoffice : endDate*/
         // Cause the datastore to do another query :
	 }
	 function closeSearch(){
	    pencarianWindow.close();
	 }
     
     function resetSearch(){
         // reset the store parameters
    		listData.baseParams = {
   			task: 'data'
   		};
         // Cause the datastore to do another query : 
   		listData.reload();
        pencarianWindow.close();
     }
     
     // once all is done, show the search window
   //  pencarianWindow.show();
	  
	  


        var cbGrid = new Ext.grid.CheckboxSelectionModel();

       var dataTable = new Ext.grid.EditorGridPanel({
            frame: true, border: true, stripeRows: true,sm:cbGrid,
            store: listData, loadMask: true, 
            style: 'margin:0 auto;font-size:14px;', width: 700,
            columns: [
              new Ext.grid.RowNumberer(), cbGrid, {
			        header: 'Lembaga',
                    dataIndex: 'id_lembaga',
                    sortable: true,
                    width: 100
                },
				{
			        header: 'Kabupaten/Kota',
                    dataIndex: 'kabupaten_kota',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Provinsi',
                    dataIndex: 'provinsi',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Program',
                    dataIndex: 'id_program',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Status',
                    dataIndex: 'status',
                    sortable: true,
                    width: 100
                }
            ],
			
		viewConfig: {
			forceFit: true
		},
       
		height:580,
		split: true,
		region: 'north',

            listeners: {
                'rowclick': function() {
                    var sm = dataTable.getSelectionModel();
                    var sel = sm.getSelections();
                }
            },
			 
            tbar: tbData,
			
            bbar: new Ext.PagingToolbar({
                pageSize: 100,
                store: listData,
                displayInfo: true
            })
        });

      dataTable.render('dataTable');
	  
	 // pencarianform.render('searching');	
        listData.load();
    });
    </script>
    <style type='text/css'>
        #divgrid {
            background: #e9e9e9;
            border: 1px solid #d3d3d3;
            margin: 20px;
            padding: 20px;
        }
    </style>

    <title>akreditasilembaga</title>
</head>
<body>
<center><h1>Daftar Akreditasi Lembaga</h1></center><br/>
<center><div id="searching"></div></center>
<br/>
 <div id='dataTable'></div>
    
     <div style="display:none">
<? 
$lembaga="";
$program="";
$asesor="";
$sqlprogram=$this->db->query("select * from program order by kode_program asc");
foreach($sqlprogram->result() as $rowprogram){
$program .="<option value='".$rowprogram->id_program."'>".$rowprogram->kode_program." / ".$rowprogram->nama_program."</option>";
}



$prov="";
$kabupaten="";

$sql=$this->db->query("select * from provinsi order by kode asc");
foreach($sql->result() as $row){
$prov .="<option value='".$row->id_provinsi."'>".$row->kode." / ".$row->provinsi."</option>";
}
/*$sqlkabupaten=$this->db->query("select * from kabupatenkota order by kode asc");
foreach($sqlkabupaten->result() as $rowkabupaten){
$kabupaten .="<option value='".$rowkabupaten->id_kabupatenkota."'>".$rowkabupaten->kode." / ".$rowkabupaten->kabupaten_kota."</option>";
}*/
?>
<select id="provinsisearch">
<option value="0">Semua Provinsi</option>
<?=$prov?>
</select>
<!--<select id="kabupatensearch">
<?=$kabupaten?>
</select>-->
   <select id="asesoradd">
<?=$asesor?>
</select>
<select id="asesoredit">
<?=$asesor?>
</select>  
 <select id="asesoradd2">
<?=$asesor?>
</select>
<select id="asesoredit2">
<?=$asesor?>
</select>  
<select id="programadd">
<?=$program?>
</select>
<select id="programedit">
<?=$program?>
</select>

</select>

</div>
</body>
</html>