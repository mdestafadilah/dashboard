<html>
<head>
    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/js/ext/resources/css/ext-all.css'/>

    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/adapter/ext/ext-base.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/ext-all.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/FileUploadField.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/searchfield.js'></script>
     
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/expander.js'></script>
	    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/css/fileuploadfield.css'/>
		 <link rel='stylesheet' type='text/css' href='<?=base_url()?>assets/js/ext/resources/css/xtheme-gray.css' />
    <script type='text/javascript'>
    var BASE_URL = '<?php echo base_url(); ?>' + '/';
    var BASE_PATH = '<?php echo base_url(); ?>';
    var BASE_ICONS = BASE_PATH + 'assets/icons/';
    Ext.onReady(function() {
        var listData = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                fields: [
                   'id_asesor','no_urut_asesor','nama','angkatan','bulan','tahun','id_program','jenis_kelamin','alamat_surat_menyurat','alamat_kantor','email','telepon','id_kabupatenkota','id_provinsi','id_jabatan','status','angkatan_asesor','no_sertifikat'
                ],
                root: 'rows', totalProperty: 'results'
            }),
            proxy: new Ext.data.HttpProxy({
                url: BASE_URL + 'asesor/get_all_data',
                method: 'POST'
            })
        });

        var searchData = new Ext.app.SearchField({
            store: listData,
            params: {start: 0, limit: 100},
            width: 180,
            id: 'fieldUsersSearch'
        });
	var formAdd= new Ext.form.FormPanel({
	    url:BASE_URL + 'asesor/add',
        baseCls: 'x-plain',
        labelWidth: 90,
		fileUpload:true,
        items: [
			 {
		   xtype:'tabpanel',
            activeTab: 0,
            defaults:{
			layout:'form',	
			autoHeight:true, bodyStyle:'padding:10px'}, 
            items:[{
            title: 'Data 1',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[{
			xtype: 'textfield',
		fieldLabel: 'No Urut Asesor',
		id:'no_urut_asesor1',
		anchor: '80%',
		name: 'no_urut_asesor'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Nama',
		id:'nama1',
		anchor: '80%',
		name: 'nama'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Angkatan',
		id:'angkatan1',
		anchor: '80%',
		name: 'angkatan'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Bulan',
		id:'bulan1',
		anchor: '80%',
		name: 'bulan'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Tahun',
		id:'tahun1',
		anchor: '80%',
		name: 'tahun'
		},  {
				xtype: 'combo',
        transform:'programadd',
		hiddenName : 'id_program',
        fieldLabel:'Kompetensi', 
        typeAhead: true,
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Program',
        selectOnFocus:true,
		id:'id_program1',
		anchor: '80%',
		name: 'id_program'
		},  {
		xtype: 'combo',
        transform:'jkadd',
		hiddenName : 'jenis_kelamin',
        fieldLabel:'Jenis Kelamin', 
        typeAhead: true,
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Jenis Kelamin',
        selectOnFocus:true,
		id:'jenis_kelamin1',
		anchor: '80%',		
		name: 'jenis_kelamin'
		}]
		},{
		   title: 'Data 2',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[
			{
			xtype: 'textfield',
		fieldLabel: 'Alamat Surat Menyurat',
		id:'alamat_surat_menyurat1',
		anchor: '80%',
		name: 'alamat_surat_menyurat'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Alamat Kantor',
		id:'alamat_kantor1',
		anchor: '80%',
		name: 'alamat_kantor'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Email',
		id:'email1',
		anchor: '80%',
		name: 'email'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Telepon',
		id:'telepon1',
		anchor: '80%',
		name: 'telepon'
		},   {
			xtype: 'combo',
        transform:'provinsiadd',
		hiddenName : 'id_provinsi',
         fieldLabel:'Provinsi', 
        typeAhead: true,
		id:'id_provinsi1',
		anchor: '80%',
		 forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Provinsi',
        selectOnFocus:true,
		name: 'id_provinsi'
		},  {
			xtype: 'combo',
        transform:'kabupatenadd',
		hiddenName : 'id_kabupatenkota',
        fieldLabel:'Kabupaten/Kota', 
        typeAhead: true,
		id:'id_kabupatenkota1',
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Kabupaten/Kota',
        selectOnFocus:true,
		name: 'id_kabupatenkota'
		},  {
				xtype: 'combo',
        transform:'jabatanadd',
		hiddenName : 'id_jabatan',
        fieldLabel:'Jabatan', 
        typeAhead: true,
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Jabatan',
        selectOnFocus:true,
		anchor: '80%',
		id:'id_jabatan1',
		anchor: '80%',
		name: 'id_jabatan'
		},  {
		xtype: 'combo',
        transform:'statusadd',
		hiddenName : 'status',
        fieldLabel:'status', 
        typeAhead: true,
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Status',
        selectOnFocus:true,
		id:'status1',
		name: 'status'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Angkatan Asesor',
		id:'angkatan_asesor1',
		anchor: '80%',
		name: 'angkatan_asesor'
		}, 
		{
		 xtype: 'textfield',
		fieldLabel: 'No Sertifikat',
		anchor: '80%',
		id:'no_sertifikat1',
		name: 'no_sertifikat'
		}
		]
        }
		
		
			
		] }],
		buttons: [{
            text: 'Simpan',
			handler:function(){
				formAdd.getForm().submit({
					waitMsg:'Data sedang di proses',
					failure: function(form, action) {
						Ext.MessageBox.alert('Error Message', 'Gagal tambah data !');
						formAdd.getForm().reset();
					},
					success: function(form, action) {
						Ext.MessageBox.alert('Confirm', 'Data  berhasil ditambah');
						listData.load({params:{start:0,limit:100}});
						window.hide();
						formAdd.getForm().reset();
					}
				})
			}
        },{
            text: 'Reset',
			handler: function(){
formAdd.getForm().reset();
			}
        }]
	});

var window = new Ext.Window({
		title: 'Tambah Data',
        width: 500,
        height:420,        
		layout:'card',
		autoScroll: true,
        plain:true,
        bodyStyle:'padding:3px;',
        buttonAlign:'center',
		closeAction:'hide',
		modal: true,
		maximizable:true,
		
		animCollapse:true,
		activeItem:0,
        items: [
		formAdd
		]
    });
	var formEditData= new Ext.form.FormPanel({
	    url:BASE_URL + 'asesor/editData',
         fileUpload: true,
		baseCls: 'x-plain',
        labelWidth: 90,
		

	reader: new Ext.data.JsonReader ({
			root: 'results',
			totalProperty: 'rows',
			id: 'id2',
			fields: [
							
			  'id_asesor','no_urut_asesor','nama','angkatan','bulan','tahun','id_program','jenis_kelamin','alamat_surat_menyurat','alamat_kantor','email','telepon','id_kabupatenkota','id_provinsi','id_jabatan','status','angkatan_asesor','no_sertifikat'
			]
		}),
        items: [
			new Ext.form.Hidden ({
				name: 'id_asesor'
			}),
			{
		   xtype:'tabpanel',
            activeTab: 0,
            defaults:{
			layout:'form',	
			autoHeight:true, bodyStyle:'padding:10px'}, 
            items:[{
            title: 'Data 1',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[{
			xtype: 'textfield',
		fieldLabel: 'No Urut Asesor',
		id:'no_urut_asesor2',
		anchor: '80%',
		name: 'no_urut_asesor'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Nama',
		id:'nama2',
		anchor: '80%',
		name: 'nama'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Angkatan',
		id:'angkatan2',
		anchor: '80%',
		name: 'angkatan'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Bulan',
		id:'bulan2',
		anchor: '80%',
		name: 'bulan'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Tahun',
		id:'tahun2',
		anchor: '80%',
		name: 'tahun'
		},   {
				xtype: 'combo',
        transform:'programedit',
		hiddenName : 'id_program',
        fieldLabel:'Kompetensi', 
        typeAhead: true,
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Program',
        selectOnFocus:true,
		id:'id_program2',
		anchor: '80%',
		name: 'id_program'
		}, {
			xtype: 'combo',
        transform:'jkedit',
		hiddenName : 'jenis_kelamin',
        fieldLabel:'Jenis Kelamin', 
        typeAhead: true,
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Jenis Kelamin',
        selectOnFocus:true,
		id:'jenis_kelamin2',
		anchor: '80%',		
		name: 'jenis_kelamin'
		}]
		},{
		   title: 'Data 2',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[
			{
			xtype: 'textfield',
		fieldLabel: 'Alamat Surat Menyurat',
		id:'alamat_surat_menyurat2',
		anchor: '80%',
		name: 'alamat_surat_menyurat'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Alamat Kantor',
		id:'alamat_kantor2',
		anchor: '80%',
		name: 'alamat_kantor'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Email',
		id:'email2',
		anchor: '80%',
		name: 'email'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Telepon',
		id:'telepon2',
		anchor: '80%',
		name: 'telepon'
		},  {
			xtype: 'combo',
        transform:'provinsiedit',
		hiddenName : 'id_provinsi',
        fieldLabel:'Provinsi', 
        typeAhead: true,
		id:'id_provinsi2',
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Provinsi',
        selectOnFocus:true,
		name: 'id_provinsi'
		}, {
		xtype: 'combo',
        transform:'kabupatenedit',
		hiddenName : 'id_kabupatenkota',
        fieldLabel:'Kabupaten/Kota', 
        typeAhead: true,
		id:'id_kabupatenkota2',
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Kabupaten/Kota',
        selectOnFocus:true,
		name: 'id_kabupatenkota'
		},  {
						xtype: 'combo',
        transform:'jabatanedit',
		hiddenName : 'id_jabatan',
        fieldLabel:'Jabatan', 
        typeAhead: true,
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Jabatan',
        selectOnFocus:true,
		anchor: '80%',
		id:'id_jabatan2',
		anchor: '80%',
		name: 'id_jabatan'

		},  {
			xtype: 'combo',
        transform:'statusedit',
		hiddenName : 'status',
        fieldLabel:'status', 
        typeAhead: true,
		anchor: '80%',
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Status',
        selectOnFocus:true,
		id:'status2',
		name: 'status'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Angkatan Asesor',
		id:'angkatan_asesor2',
		anchor: '80%',
		name: 'angkatan_asesor'
		}, {
				 xtype: 'textfield',
		fieldLabel: 'No Sertifikat',
		anchor: '80%',
		id:'no_sertifikat2',
		name: 'no_sertifikat'
		}
		]
        }
		
		
			
		] }],
		
		buttons: [{
            text: 'Ubah',
			handler:function(){
				formEditData.getForm().submit({
					waitMsg:'Data sedang di proses',
					failure: function(form, action) {
						Ext.MessageBox.alert('Error Message', 'Gagal Edit Data');
						formEditData.getForm().reset();
					},
					success: function(form, action) {
						Ext.MessageBox.alert('Confirm', 'Data Berhasil di Ubah');
						listData.load({params:{start:0,limit:100}});
						windowEdit.hide();
						formEditData.getForm().reset();
					}
				})
			}
        },{
            text: 'Batal',
			handler: function(){
					windowEdit.hide();
				}
        }]
	});

	var windowEdit = new Ext.Window({
		title: 'Edit Data',
      width: 500,
        height:420,       
		layout:'card',
        plain:true,
		autoScroll: true,
        bodyStyle:'padding:3px;',
        buttonAlign:'center',
		closeAction:'hide',
		modal: true,
		maximizable:true,
		
		animCollapse:true,
		activeItem:0,
        items: [
	formEditData
		]
    });
	
        var tbData = new Ext.Toolbar({
            items:[{
                text: 'Add',
                icon: BASE_ICONS + 'add.png',
                handler: function() {
                    window.show();
                }
            } ,'-',

			{
			
			text:'Edit',
			iconCls:'edit-grid',
   icon: BASE_ICONS + 'edit.png',
			
			handler: function()
			{
				var m = dataTable.getSelectionModel().getSelections();
				if(m.length > 0)
				{				
					formEditData.getForm().load({url:BASE_URL + 'asesor/getData/'+ m[0].get('id_asesor'), waitMsg:'Loading'});
					windowEdit.show();			 
				}
				else
				{
					Ext.MessageBox.alert('Message', 'Pilih data!');
				}
			
			}
		 
		 }
			, '-', {
                text: 'Delete',
                icon: BASE_ICONS + 'delete.png',
                  handler: function()
			{
				var m = dataTable.getSelectionModel().getSelections();
				if(m.length > 0)
				{	  Ext.Msg.show({
                title: 'Confirm',
                msg: 'Hapus Data Ini ?',
                buttons: Ext.Msg.YESNO,
                fn: function(btn) {
                    if (btn == 'yes') {
                        var sm = dataTable.getSelectionModel();
                        var sel = sm.getSelections();
                        var data = '';
                        for (i = 0; i<sel.length; i++) {
                            data = data + sel[i].get('id_asesor') + ';';
                        }
						


                        Ext.Ajax.request({
                            url: BASE_URL + 'asesor/delete',
                            method: 'POST',
                            params: { postdata: data }
						

                        });
                        listData.load();
                    }
                }
            });
					}
				else
				{
					Ext.MessageBox.alert('Message', 'Pilih data!');
				}
			
			}
            }, '-', {
            text: 'Search',
            tooltip: 'Advanced Search',
            handler: startAdvancedSearch,  // search function
             icon: BASE_ICONS + 'search.png',               // we'll need to add this to our css
          },'-',

			{
			
			text:'Dokumen',
             icon: BASE_ICONS + 'documen.gif',
			
			handler: function()
			{
			var m = dataTable.getSelectionModel().getSelections();
				if(m.length > 0)
				{	
			var window5 = new Ext.Window({
		title: 'Dokumen',
        width: 820,
        height:450,        
		layout:'card',
        plain:true,
        bodyStyle:'padding:3px;',
        buttonAlign:'center',
		closeAction:'hide',
		modal: true,
		maximizable:true,
		
		animCollapse:true,
		html:"<iframe src='dokumenasesor/index/"+m[0].get('id_asesor')+"' style='width:100%;height:100%' frameborder='0'><iframe>"
    
    });
					window5.show();		
			}else {
				Ext.MessageBox.alert('Message', 'Pilih data!');
			
			}
		 
		 }
		 }
		/*, '->', searchData*/]
        });

        
                   
        function deleteData() {
            Ext.Msg.show({
                title: 'Confirm',
                msg: 'Hapus Data ini ?',
                buttons: Ext.Msg.YESNO,
                fn: function(btn) {
                    if (btn == 'yes') {
                        var sm = dataTable.getSelectionModel();
                        var sel = sm.getSelections();
                        var data = '';
                        for (i = 0; i<sel.length; i++) {
                            data = data + sel[i].get('id_asesor') + ';';
                        }
						


                        Ext.Ajax.request({
                            url: BASE_URL + 'asesor/delete',
                            method: 'POST',
                            params: { postdata: data }
						

                        });
                        listData.load();
                    }
                }
            });
        }




 function startAdvancedSearch(){
  var nama;
  
  nama = new Ext.form.TextField({
          fieldLabel: 'Nama',
          maxLength: 20,
          anchor : '95%',
          maskRe: /([a-zA-Z0-9\s]+)$/
            });
			
			      status = new Ext.form.ComboBox({
         fieldLabel: 'status',
         store:new Ext.data.SimpleStore({
          fields:['statusValue', 'statusName'],
          data: [['1','Aktif'],['0','Tidak aktif']]
          }),
         mode: 'local',
         displayField: 'statusName',
		 emptyText:'status',
         valueField: 'statusValue',
         anchor:'95%',
         triggerAction: 'all'
            });

  pencarianform = new Ext.FormPanel({
       labelAlign: 'top',
       bodyStyle: 'padding: 5px',
       width: 300,
       items: [{
         layout: 'form',
         border: false,
         items: [nama,status],
         buttons: [{
               text: 'Cari Data ',
               handler: listSearch
             },{
               text: 'Semua Data',
               handler: resetSearch
             }]
         }]
     });
 pencarianWindow = new Ext.Window({
         title: 'Cari data asesor',
         closable:true,
         width: 250,
         height: 250,
         plain:true,
         layout: 'fit',
         items: pencarianform
     });
	  function listSearch(){
         // render according to a SQL date format.
   /*      var startDate = "";
         var endDate = "";
         if(SearchEnteringItem.getValue() != "") {
            startDate = SearchEnteringItem.getValue().format('Y-m-d');
         }
         if(SearchLeavingItem.getValue() != "") {
            endDate = SearchLeavingItem.getValue().format('Y-m-d');
         }
     */    
         // change the store parameters
    	    listData.baseParams = {
   			task: 'cari',
   			nama: nama.getValue(),
			status: status.getValue()/*,
            lastname : SearchLastNameItem.getValue(),
            party : SearchPartyItem.getValue(),
            enteringoffice : startDate,
            leavingoffice : endDate*/
   		};
         // Cause the datastore to do another query : 
   		listData.reload();
     }
	 
	 function closeSearch(){
	    pencarianWindow.close();
	 }
     
     function resetSearch(){
         // reset the store parameters
    		listData.baseParams = {
   			task: 'data'
   		};
         // Cause the datastore to do another query : 
   		listData.reload();
        pencarianWindow.close();
     }
     
     // once all is done, show the search window
     pencarianWindow.show();
	  }
	  
	 
	 
	 
        var cbGrid = new Ext.grid.CheckboxSelectionModel();

       var dataTable = new Ext.grid.EditorGridPanel({
            frame: true, border: true, stripeRows: true,sm:cbGrid,
            store: listData, loadMask: true, 
            style: 'margin:0 auto;', width: 800,
            columns: [
              new Ext.grid.RowNumberer(), cbGrid, {
			        header: 'No Urut Asesor',
                    dataIndex: 'no_urut_asesor',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Nama',
                    dataIndex: 'nama',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Angkatan',
                    dataIndex: 'angkatan',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Bulan',
                    dataIndex: 'bulan',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Tahun',
                    dataIndex: 'tahun',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Kompetensi',
                    dataIndex: 'id_program',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Jenis Kelamin',
                    dataIndex: 'jenis_kelamin',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Alamat Surat Menyurat',
                    dataIndex: 'alamat_surat_menyurat',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Alamat Kantor',
                    dataIndex: 'alamat_kantor',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Email',
                    dataIndex: 'email',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Telepon',
                    dataIndex: 'telepon',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Kabupaten/Kota',
                    dataIndex: 'id_kabupatenkota',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Provinsi',
                    dataIndex: 'id_provinsi',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Jabatan',
                    dataIndex: 'id_jabatan',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Status',
                    dataIndex: 'status',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Angkatan Asesor',
                    dataIndex: 'angkatan_asesor',
                    sortable: true,
                    width: 100
                }, { 
		             header: 'No Sertifikat',
                    dataIndex: 'no_sertifikat',
                    sortable: true,
                    width: 100
                }  
            ],
			
		viewConfig: {
			forceFit: true
		},
       width: '100%',
		height:580,
		split: true,
		region: 'north',

            listeners: {
                'rowclick': function() {
                    var sm = dataTable.getSelectionModel();
                    var sel = sm.getSelections();
                }
            },
			 
            tbar: tbData,
			
            bbar: new Ext.PagingToolbar({
                pageSize: 100,
                store: listData,
                displayInfo: true
            })
        });

      dataTable.render('dataTable');	
        listData.load();
    });
    </script>
    <style type='text/css'>
        #divgrid {
            background: #e9e9e9;
            border: 1px solid #d3d3d3;
            margin: 20px;
            padding: 20px;
        }
    </style>

    <title>asesor</title>
</head>
<body>

 <div id='dataTable'></div>
	<div style="display:none">
<? 
$prov="";
$kabupaten="";
$program="";
$jabatan="";

$sql=$this->db->query("select * from provinsi order by kode asc");
foreach($sql->result() as $row){
$prov .="<option value='".$row->id_provinsi."'>".$row->kode." / ".$row->provinsi."</option>";
}
$sqlkabupaten=$this->db->query("select * from kabupatenkota order by kode asc");
foreach($sqlkabupaten->result() as $rowkabupaten){
$kabupaten .="<option value='".$rowkabupaten->id_kabupatenkota."'>".$rowkabupaten->kode." / ".$rowkabupaten->kabupaten_kota."</option>";
}

$sqlprogram=$this->db->query("select * from program order by kode_program asc");
foreach($sqlprogram->result() as $rowprogram){
$program .="<option value='".$rowprogram->id_program."'>".$rowprogram->kode_program." / ".$rowprogram->nama_program."</option>";
}
$sqljabatan=$this->db->query("select * from jabatan order by id_jabatan asc");
foreach($sqljabatan->result() as $rowjabatan){
$jabatan .="<option value='".$rowjabatan->id_jabatan."'>".$rowjabatan->jabatan."</option>";
}

?>
<select id="provinsiadd">
<?=$prov?>
</select>
<select id="provinsiedit">
<?=$prov?>
</select>
<select id="kabupatenadd">
<?=$kabupaten?>
</select>
<select id="kabupatenedit">
<?=$kabupaten?>
</select>
<select id="programadd">
<?=$program?>
</select>
<select id="programedit">
<?=$program?>
</select>
<select id="jabatanadd">
<?=$jabatan?>
</select>
<select id="jabatanedit">
<?=$jabatan?>
</select>

<select id="jkadd">
<option value="L">Laki-Laki</option>
<option value="P">Perempuan</option>
</select>
<select id="jkedit">
<option value="L">Laki-Laki</option>
<option value="P">Perempuan</option>
</select>
<select id="statusadd">
<option value="1">Aktif</option>
<option value="0">Tidak Aktif</option>
</select>
<select id="statusedit">
<option value="1">Aktif</option>
<option value="0">Tidak Aktif</option>
</select>

</div>
</body>
</html>