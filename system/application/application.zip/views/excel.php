<?php 
   
	
	
	echo "<h3>DAFTAR PROGRAM DALAM SATUAN PNF YANG TELAH TERAKREDITASI</h3>";
		$query=$this->akreditasilembagauser_model->get_all_data_print($n,$s,$p);
	    echo "<table border=1><tr>
		<td>No</td>
		<td>Nama Lembaga</td>
		<td>Provinsi</td>
		<td>Kab/Kota</td>
		<td>Program</td>
		<td>Status Akreditasi</td>
		</tr>
		";
		$no=0;
		  foreach ($query->result() as $obj)
        {
		++$no;
		    if($obj->status==0)$status2='Belum terakreditasi';
			else if($obj->status==1)$status2='Terakreditasi';
			else if($obj->status==2)$status2='Ditunda';
	
	echo "<tr>
	<td>".$no."</td>
	<td>".$obj->nama_lembaga."</td>
	<td>".$obj->provinsi."</td>
	<td>".$obj->kabupaten_kota."</td>
	<td>".$obj->nama_lembaga."</td>
	<td>".$status2."</td></tr>";
             }
			 echo "</table>";
   ?>