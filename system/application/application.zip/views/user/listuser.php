<html>
<head>
    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/js/ext/resources/css/ext-all.css'/>

    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/adapter/ext/ext-base.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/ext-all.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/FileUploadField.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/searchfield.js'></script>
     
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/expander.js'></script>
	    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/css/fileuploadfield.css'/>
		 <link rel='stylesheet' type='text/css' href='<?=base_url()?>assets/js/ext/resources/css/xtheme-gray.css' />
    <script type='text/javascript'>
    var BASE_URL = '<?php echo base_url(); ?>' + '/';
    var BASE_PATH = '<?php echo base_url(); ?>';
    var BASE_ICONS = BASE_PATH + 'assets/icons/';
    Ext.onReady(function() {
        var listData = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                fields: [
                   'id_user','id_karyawan','role','username','last_login','ip'
                ],
                root: 'rows', totalProperty: 'results'
            }),
            proxy: new Ext.data.HttpProxy({
                url: BASE_URL + 'user/get_all_data',
                method: 'POST'
            })
        });

        var searchData = new Ext.app.SearchField({
            store: listData,
            params: {start: 0, limit: 100},
            width: 180,
            id: 'fieldUsersSearch'
        });
	var formAdd= new Ext.form.FormPanel({
	    url:BASE_URL + 'user/add',
        baseCls: 'x-plain',
        labelWidth: 90,
		fileUpload:true,
        items: [
			 {
		   xtype:'tabpanel',
            activeTab: 0,
            defaults:{
			layout:'form',	
			autoHeight:true, bodyStyle:'padding:10px'}, 
            items:[{
            title: 'Data ',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[{
						xtype: 'combo',
        transform:'karyawanadd',
		hiddenName : 'id_karyawan',
        fieldLabel:'Karyawan', 
        typeAhead: true,
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Karyawan',
        selectOnFocus:true,
		id:'id_karyawan1',
		anchor: '80%',
		name: 'id_karyawan'
		}, 
		 {
			xtype: 'textfield',
		fieldLabel: 'Username',
		id:'user1',
		anchor: '80%',
		allowBlank:false,
		name: 'username'
		},
		 {
			xtype: 'textfield',
		fieldLabel: 'password',
		id:'password1',
		inputType:'password',
		anchor: '80%',
		allowBlank:false,
		name: 'password'
		}]
		},{
		   title: 'Akses modul',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[
			{
            // Use the default, automatic layout to distribute the controls evenly
            // across a single row
            xtype: 'checkbox',
            fieldLabel: 'Master',
			name:'master',
			id:'master1'
            /*items: [
                {boxLabel: 'Master', name: 'master', value: 1},
                {boxLabel: 'Cek Berkas Awal', name: 'berkas1', value: 1},
                {boxLabel: 'Item 3', name: 'cb-auto-3'},
                {boxLabel: 'Item 4', name: 'cb-auto-4'},
                {boxLabel: 'Item 5', name: 'cb-auto-5'}
            ]*/
        }
		
		,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Surat Masuk',
			name:'suratmasuk',
			id:'suratmasuk1'
			}
		,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Permohonan',
			name:'berkas1',
			id:'berkas1'
		},
		{
		          xtype: 'checkbox',
            fieldLabel: 'Pendaftaran',
			name:'pendaftaran',
			id:'pendaftaran1'
		}
		,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Balas Surat',
			name:'balas',
			id:'balas'
		}
		,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Lembaga',
			name:'lembaga',
			id:'lembaga1'
		}
			,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Asesor',
			name:'asesor',
			id:'asesor1'
		},
		{
		          xtype: 'checkbox',
            fieldLabel: 'Akreditasi',
			name:'akreditasi',
			id:'akreditasi1'
		}
	
		]
        }
		
		
			
		] }],
		buttons: [{
            text: 'Simpan',
			handler:function(){
			  if(formAdd.getForm().isValid()){
				formAdd.getForm().submit({
					waitMsg:'Data sedang di proses',
					failure: function(form, action) {
						Ext.MessageBox.alert('Error Message', 'Gagal tambah data !');
						formAdd.getForm().reset();
					},
					success: function(form, action) {
						Ext.MessageBox.alert('Confirm', 'Data  berhasil ditambah');
						listData.load({params:{start:0,limit:100}});
						window.hide();
						formAdd.getForm().reset();
					}
				})
			}
			}
        },{
            text: 'Reset',
			handler: function(){
formAdd.getForm().reset();
			}
        }]
	});

var window = new Ext.Window({
		title: 'Tambah Data',
        width: 500,
        height:320,        
		layout:'card',
        plain:true,
        bodyStyle:'padding:3px;',
        buttonAlign:'center',
		closeAction:'hide',
		modal: true,
		maximizable:true,
		
		animCollapse:true,
		activeItem:0,
        items: [
		formAdd
		]
    });
	
	
	
	
	
	
	var formEditData= new Ext.form.FormPanel({
	    url:BASE_URL + 'user/editData',
         fileUpload: true,
		baseCls: 'x-plain',
        labelWidth: 90,
		

	reader: new Ext.data.JsonReader ({
			root: 'results',
			totalProperty: 'rows',
			id: 'id2',
			fields: [
							
			  'id_user','id_karyawan','role','username','master','berkas1','lembaga','asesor','balas','pendaftaran','akreditasi','suratmasuk'
			]
		}),
        items: [
			new Ext.form.Hidden ({
				name: 'id_user'
			}),
			
			 {
		   xtype:'tabpanel',
            activeTab: 0,
            defaults:{
			layout:'form',	
			autoHeight:true, bodyStyle:'padding:10px'}, 
            items:[{
            title: 'Data ',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[{
			xtype: 'combo',
        transform:'karyawanedit',
		hiddenName : 'id_karyawan',
        fieldLabel:'Karyawan', 
        typeAhead: true,
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Karyawan',
        selectOnFocus:true,
		id:'id_karyawan2',
		anchor: '80%',
		name: 'id_karyawan'
		}, 
		 {
			xtype: 'textfield',
		fieldLabel: 'Username',
		id:'user2',
		anchor: '80%',
		allowBlank:false,
		name: 'username'
		},
		 {
			xtype: 'textfield',
		fieldLabel: 'password',
		id:'password2',
		inputType:'password',
		anchor: '80%',
		name: 'password'
		},
		{
                    xtype:'label',
                    text: "Biarkan kosong bila password tidak ingin diganti",
                    name: 'passlabel',
                    labelStyle: 'font-weight:bold;color:red;',
                    anchor:'93%'
              }]
		},{
		   title: 'Akses modul',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[
			{
            // Use the default, automatic layout to distribute the controls evenly
            // across a single row
            xtype: 'checkbox',
            fieldLabel: 'Master',
			name:'master',
			id:'master2'
            /*items: [
                {boxLabel: 'Master', name: 'master', value: 1},
                {boxLabel: 'Cek Berkas Awal', name: 'berkas1', value: 1},
                {boxLabel: 'Item 3', name: 'cb-auto-3'},
                {boxLabel: 'Item 4', name: 'cb-auto-4'},
                {boxLabel: 'Item 5', name: 'cb-auto-5'}
            ]*/
        },
		{
		          xtype: 'checkbox',
            fieldLabel: 'Surat Masuk',
			name:'suratmasuk',
			id:'suratmasuk2'
			}
		,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Permohonan',
			name:'berkas1',
			id:'berkas2'
			}
		,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Pendaftaran',
			name:'pendaftaran',
			id:'pendaftaran2'
		},
		{
		          xtype: 'checkbox',
            fieldLabel: 'Balas Surat',
			name:'balas',
			id:'balas2'
		}
		,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Lembaga',
			name:'lembaga',
			id:'lembaga2'
		}
			,
		{
		          xtype: 'checkbox',
            fieldLabel: 'Asesor',
			name:'asesor',
			id:'asesor2'
	},
	{
		          xtype: 'checkbox',
            fieldLabel: 'Akreditasi',
			name:'akreditasi',
			id:'akreditasi2'
		}
		
		]
        }
		
		
			
		] }],
		buttons: [{
            text: 'Ubah',
			handler:function(){
				formEditData.getForm().submit({
					waitMsg:'Data sedang di proses',
					failure: function(form, action) {
						Ext.MessageBox.alert('Error Message', 'Gagal Edit Data');

						formEditData.getForm().reset();
					},
					success: function(form, action) {
						Ext.MessageBox.alert('Confirm', 'Data Berhasil di Ubah');
						listData.load({params:{start:0,limit:100}});
						windowEdit.hide();
						formEditData.getForm().reset();
					}
				})
			}
        },{
            text: 'Batal',
			handler: function(){
					windowEdit.hide();
				}
        }]
	});

	var windowEdit = new Ext.Window({
		title: 'Edit Data',
      width: 500,
        height:320,       
		layout:'card',
        plain:true,
        bodyStyle:'padding:3px;',
        buttonAlign:'center',
		closeAction:'hide',
		modal: true,
		maximizable:true,
		
		animCollapse:true,
		activeItem:0,
        items: [
	formEditData
		]
    });
	
        var tbData = new Ext.Toolbar({
            items:[{
                text: 'Add',
                icon: BASE_ICONS + 'add.png',
                handler: function() {
                    window.show();
                }
            } ,'-',

			{
			
			text:'Edit',
			iconCls:'edit-grid',
   icon: BASE_ICONS + 'edit.png',
			
			handler: function()
			{
				var m = dataTable.getSelectionModel().getSelections();
				if(m.length > 0)
				{				
					formEditData.getForm().load({url:BASE_URL + 'user/getData/'+ m[0].get('id_user'), waitMsg:'Loading'});
					windowEdit.show();			 
				}
				else
				{
					Ext.MessageBox.alert('Message', 'Pilih data!');
				}
			
			}
		 
		 }
			, '-', {
                text: 'Delete',
                icon: BASE_ICONS + 'delete.png',
                  handler: function()
			{
				var m = dataTable.getSelectionModel().getSelections();
				if(m.length > 0)
				{	  Ext.Msg.show({
                title: 'Confirm',
                msg: 'Hapus Data Ini ?',
                buttons: Ext.Msg.YESNO,
                fn: function(btn) {
                    if (btn == 'yes') {
                        var sm = dataTable.getSelectionModel();
                        var sel = sm.getSelections();
                        var data = '';
                        for (i = 0; i<sel.length; i++) {
                            data = data + sel[i].get('id_user') + ';';
                        }
						


                        Ext.Ajax.request({
                            url: BASE_URL + 'user/delete',
                            method: 'POST',
                            params: { postdata: data }
						

                        });
                        listData.load();
                    }
                }
            });
					}
				else
				{
					Ext.MessageBox.alert('Message', 'Pilih data!');
				}
			
			}
            }
		, '->', searchData]
        });

        
                   
        function deleteData() {
            Ext.Msg.show({
                title: 'Confirm',
                msg: 'Hapus Data ini ?',
                buttons: Ext.Msg.YESNO,
                fn: function(btn) {
                    if (btn == 'yes') {
                        var sm = dataTable.getSelectionModel();
                        var sel = sm.getSelections();
                        var data = '';
                        for (i = 0; i<sel.length; i++) {
                            data = data + sel[i].get('id_user') + ';';
                        }
						


                        Ext.Ajax.request({
                            url: BASE_URL + 'user/delete',
                            method: 'POST',
                            params: { postdata: data }
						

                        });
                        listData.load();
                    }
                }
            });
        }

        var cbGrid = new Ext.grid.CheckboxSelectionModel();

       var dataTable = new Ext.grid.EditorGridPanel({
            frame: true, border: true, stripeRows: true,sm:cbGrid,
            store: listData, loadMask: true, 
            style: 'margin:0 auto;', width: 800,
            columns: [
              new Ext.grid.RowNumberer(), cbGrid, {
			  
			        header: 'Karyawan',
                    dataIndex: 'id_karyawan',
                    sortable: true,
                    width: 100
                }, { 
		             header: 'Username',
                    dataIndex: 'username',
                    sortable: true,
                    width: 100
                }  ,{ 
		             header: 'Last Login',
                    dataIndex: 'last_login',
                    sortable: true,
                    width: 100
                } ,{ 
		             header: 'Alamat IP',
                    dataIndex: 'ip',
                    sortable: true,
                    width: 100
                }, { 
		             header: 'Role',
                    dataIndex: 'role',
                    sortable: true,
                    width: 100
                }  
            ],
			
		viewConfig: {
			forceFit: true
		},
       width: '100%',
		height:580,
		split: true,
		region: 'north',

            listeners: {
                'rowclick': function() {
                    var sm = dataTable.getSelectionModel();
                    var sel = sm.getSelections();
                }
            },
			 
            tbar: tbData,
			
            bbar: new Ext.PagingToolbar({
                pageSize: 100,
                store: listData,
                displayInfo: true
            })
        });

      dataTable.render('dataTable');	
        listData.load();
    });
    </script>
    <style type='text/css'>
        #divgrid {
            background: #e9e9e9;
            border: 1px solid #d3d3d3;
            margin: 20px;
            padding: 20px;
        }
    </style>

    <title>user</title>
</head>
<body>

 <div id='dataTable'></div>
	<div style="display:none">
	<?
$karyawan="";

$sql=$this->db->query("select * from karyawan order by nama asc");
foreach($sql->result() as $row){
$karyawan .="<option value='".$row->id_karyawan."'>".$row->nip." / ".$row->nama."</option>";
}

?>
<select id="karyawanadd">
<?=$karyawan?>
</select>
<select id="karyawanedit">
<?=$karyawan?>
</select>
</div>
</body>
</html>