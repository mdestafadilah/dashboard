<html>
<head>
    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/js/ext/resources/css/ext-all.css'/>

    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/adapter/ext/ext-base.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/ext-all.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/FileUploadField.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/plugins/searchfield.js'></script>
     
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/ext/expander.js'></script>
	    <link rel='stylesheet' type='text/css' href='<?php echo base_url(); ?>assets/css/fileuploadfield.css'/>
		 <link rel='stylesheet' type='text/css' href='<?=base_url()?>assets/js/ext/resources/css/xtheme-gray.css' />
    <script type='text/javascript'>
    var BASE_URL = '<?php echo base_url(); ?>' + '/';
    var BASE_PATH = '<?php echo base_url(); ?>';
    var BASE_ICONS = BASE_PATH + 'assets/icons/';
    Ext.onReady(function() {
        var listData = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                fields: [
                   'id_permohonan','no_permohonan','tgl_terimasurat','no_surat','pemohon','id_lembaga','permohonan','pernyataan','formulir','izin_operasional','akta','keterangan','id_program','no_suratbalasan','tgl_pengiriman','proses','keterangan_balasan','instrumen','lampiran'
                ],
                root: 'rows', totalProperty: 'results'
            }),
            proxy: new Ext.data.HttpProxy({
                url: BASE_URL + 'pendaftaran/get_all_data',
                method: 'POST'
            })
        });

        var searchData = new Ext.app.SearchField({
            store: listData,
            params: {start: 0, limit: 100},
            width: 180,
            id: 'fieldUsersSearch'
        });
	var formAdd= new Ext.form.FormPanel({
	    url:BASE_URL + 'permohonan/add',
        baseCls: 'x-plain',
        labelWidth: 90,
		fileUpload:true,
        items: [
			 {
		   xtype:'tabpanel',
            activeTab: 0,
            defaults:{
			layout:'form',	
			autoHeight:true, bodyStyle:'padding:10px'}, 
            items:[{
            title: 'Keterangan',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[{
			xtype: 'textfield',
		fieldLabel: 'No Permohonan',
		id:'no_permohonan1',
		anchor: '80%',
		name: 'no_permohonan'
		},  {
				xtype:'datefield',
		anchor: '60%',
        format:'Y-m-d',
		fieldLabel: 'Tanggal Terima surat',
		id:'tgl_terimasurat1',
		name: 'tgl_terimasurat'
		},  {
			xtype: 'textfield',
		fieldLabel: 'No Surat',
		id:'no_surat1',
		anchor: '80%',
		name: 'no_surat'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Pemohon',
		id:'pemohon1',
		anchor: '80%',
		name: 'pemohon'
		},  {
		xtype: 'combo',
        transform:'lembagaadd',
		hiddenName : 'id_lembaga',
        fieldLabel:'Lembaga', 
        typeAhead: true,
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Lembaga',
        selectOnFocus:true,
		id:'id_lembaga1',
		anchor: '80%',	
		name: 'id_lembaga'
		}, 
		 {
				xtype: 'combo',
        transform:'programadd',
		hiddenName : 'id_program',
        fieldLabel:'Program', 
        typeAhead: true,
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Program',
        selectOnFocus:true,
		id:'id_program1',
		anchor: '80%',
		name: 'id_program'
		},
		{
		 xtype: 'textarea',
		fieldLabel: 'Keterangan',
		anchor: '80%',
		id:'keterangan1',
		name: 'keterangan'
		}]
		},{
		   title: 'Status',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[
			 {
			xtype: 'checkbox',
		fieldLabel: 'Permohonan',
		id:'permohonan1',
		anchor: '80%',
		name: 'permohonan'
		},  {
			xtype: 'checkbox',
		fieldLabel: 'Pernyataan',
		id:'pernyataan1',
		anchor: '80%',
		name: 'pernyataan'
		},  {
			xtype: 'checkbox',
		fieldLabel: 'Formulir',
		id:'formulir1',
		anchor: '80%',
		name: 'formulir'
		},  {
			xtype: 'checkbox',
		fieldLabel: 'Izin Operasional',
		id:'izin_operasional1',
		anchor: '80%',
		name: 'izin_operasional'
		},  {
			xtype: 'checkbox',
		fieldLabel: 'Akta',
		id:'akta1',
		anchor: '80%',
		name: 'akta'
			}
		]
        }
		
		
			
		] }],
		buttons: [{
            text: 'Simpan',
			handler:function(){
				formAdd.getForm().submit({
					waitMsg:'Data sedang di proses',
					failure: function(form, action) {
						Ext.MessageBox.alert('Error Message', 'Gagal tambah data !');
						formAdd.getForm().reset();
					},
					success: function(form, action) {
						Ext.MessageBox.alert('Confirm', 'Data  berhasil ditambah');
						listData.load({params:{start:0,limit:100}});
						window.hide();
						formAdd.getForm().reset();
					}
				})
			}
        },{
            text: 'Reset',
			handler: function(){
formAdd.getForm().reset();
			}
        }]
	});

var window = new Ext.Window({
		title: 'Tambah Data',
        width: 500,
        height:350,        
		layout:'card',
        plain:true,
        bodyStyle:'padding:3px;',
        buttonAlign:'center',
		closeAction:'hide',
		modal: true,
		maximizable:true,
		
		animCollapse:true,
		activeItem:0,
        items: [
		formAdd
		]
    });
	var formEditData= new Ext.form.FormPanel({
	    url:BASE_URL + 'pendaftaran/editData',
         fileUpload: true,
		baseCls: 'x-plain',
        labelWidth: 90,
		

	reader: new Ext.data.JsonReader ({
			root: 'results',
			totalProperty: 'rows',
			id: 'id2',
			fields: [
							
			  'id_permohonan','no_permohonan','tgl_terimasurat','no_surat','pemohon','id_lembaga','permohonan','pernyataan','formulir','izin_operasional','akta','keterangan','id_program','no_suratbalasan','tgl_pengiriman','proses','keterangan_balasan','instrumen','lampiran'
			]
		}),
        items: [
			new Ext.form.Hidden ({
				name: 'id_permohonan'
			}),
			
			 {
		   xtype:'tabpanel',
            activeTab: 0,
            defaults:{
			layout:'form',	
			autoHeight:true, bodyStyle:'padding:10px'}, 
            items:[{
            title: 'Keterangan',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
			
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[{
			xtype: 'textfield',
		fieldLabel: 'No Permohonan',
		id:'no_permohonan2',
		anchor: '80%',
		 readOnly:true,
		name: 'no_permohonan'
		},  {
				xtype:'datefield',
		anchor: '60%',
        format:'Y-m-d',
		 readOnly:true,
		fieldLabel: 'Tanggal Terima surat',
		id:'tgl_terimasurat2',
		name: 'tgl_terimasurat'
		},  {
			xtype: 'textfield',
		fieldLabel: 'No Surat',
		id:'no_surat2',
		anchor: '80%',
		 readOnly:true,
		name: 'no_surat'
		},  {
			xtype: 'textfield',
		fieldLabel: 'Pemohon',
		id:'pemohon2',
		anchor: '80%',
		 readOnly:true,
		name: 'pemohon'
		},  {
		xtype: 'combo',
        transform:'lembagaedit',
		hiddenName : 'id_lembaga',
        fieldLabel:'Lembaga', 
        typeAhead: true,
		 readOnly:true,
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Lembaga',
        selectOnFocus:true,
		id:'id_lembaga2',
		anchor: '80%',	
		name: 'id_lembaga'
		}, {
				xtype: 'combo',
        transform:'programedit',
		hiddenName : 'id_program',
        fieldLabel:'Program', 
        typeAhead: true,
		anchor: '80%',
		 readOnly:true,
		forceSelection: true,
        triggerAction: 'all',
	    emptyText:'Program',
        selectOnFocus:true,
		id:'id_program2',
		anchor: '80%',
		name: 'id_program'
		}, {
				 xtype: 'textfield',
		fieldLabel: 'Keterangan',
		anchor: '80%',
		id:'keterangan2',
		 readOnly:true,
		name: 'keterangan'
		}]
		},{
		   title: 'Pendaftaran',
			 autoHeight:true,
			 labelWidth: 120,
			 layout:'form',
			 
            defaults: {width: 250},
            defaultType: 'textfield',
            items :[
			  {
			xtype: 'checkbox',
		fieldLabel: 'Proses Daftar',
		id:'proses2',
		inputValue:2,
		anchor: '80%',
		readOnly:true,
		name: 'proses'
		},  {
		xtype: 'checkbox',
		fieldLabel: 'Instrumen',
		id:'instrumen2',
		anchor: '80%',
		inputValue:1,
		 readOnly:true,
		name: 'instrumen'
		},  {
			xtype: 'checkbox',
		fieldLabel: 'Lampiran',
		id:'lampiran2',
		inputValue:1,
		anchor: '80%',
		 readOnly:true,
		name: 'lampiran'
		}/*,  {
			xtype: 'checkbox',
		fieldLabel: 'Izin Operasional',
		id:'izin_operasional2',
		anchor: '80%',
		inputValue:1,
		 readOnly:true,
		name: 'izin_operasional'
		,  {
			xtype: 'checkbox',
		fieldLabel: 'Surat balas',
		id:'proses2',
		 readOnly:true,
		inputValue:1,
		anchor: '80%',
		name: 'proses'
			},
			{
			xtype: 'textfield',
		fieldLabel: 'No Surat Balasan',
		id:'no_suratbalasan2',
		anchor: '80%',
		name: 'no_suratbalasan'
		},  {
				xtype:'datefield',
		anchor: '60%',
        format:'Y-m-d',
		fieldLabel: 'Tanggal Terima surat',
		id:'tgl_pengiriman2',
		name: 'tgl_pengiriman'
		},
		  {
			xtype: 'textarea',
		fieldLabel: 'Keterangan Surat Balasan',
		id:'keterangan_balasan2',
		name: 'keterangan_balasan'
		}*/
		]
        }
		
		
			
		] }],
		
		buttons: [{
            text: 'Ubah',
			handler:function(){
				formEditData.getForm().submit({
					waitMsg:'Data sedang di proses',
					failure: function(form, action) {
						Ext.MessageBox.alert('Error Message', 'Gagal Edit Data');
						formEditData.getForm().reset();
					},
					success: function(form, action) {
						Ext.MessageBox.alert('Confirm', 'Data Berhasil di Ubah');
						listData.load({params:{start:0,limit:100}});
						windowEdit.hide();
						formEditData.getForm().reset();
					}
				})
			}
        },{
            text: 'Batal',
			handler: function(){
					windowEdit.hide();
				}
        }]
	});

	var windowEdit = new Ext.Window({
		title: 'Edit Data',
      width: 500,
        height:350,       
		layout:'card',
        plain:true,
        bodyStyle:'padding:3px;',
        buttonAlign:'center',
		closeAction:'hide',
		modal: true,
		maximizable:true,
		
		animCollapse:true,
		activeItem:0,
        items: [
	formEditData
		]
    });
	
        var tbData = new Ext.Toolbar({
            items:[/*{
                text: 'Add',
                icon: BASE_ICONS + 'add.png',
                handler: function() {
                    window.show();
                }
            } ,'-',
*/
			{
			
			text:'Daftar Permohonan',
			iconCls:'edit-grid',
   icon: BASE_ICONS + 'edit.png',
			
			handler: function()
			{
				var m = dataTable.getSelectionModel().getSelections();
				if(m.length > 0)
				{				
					formEditData.getForm().load({url:BASE_URL + 'pendaftaran/getData/'+ m[0].get('id_permohonan'), waitMsg:'Loading'});
					windowEdit.show();			 
				}
				else
				{
					Ext.MessageBox.alert('Message', 'Pilih data!');
				}
			
			}
		 
		 }
			, '-',/* {
                text: 'Delete',
                icon: BASE_ICONS + 'delete.png',
                  handler: function()
			{
				var m = dataTable.getSelectionModel().getSelections();
				if(m.length > 0)
				{	  Ext.Msg.show({
                title: 'Confirm',
                msg: 'Hapus Data Ini ?',
                buttons: Ext.Msg.YESNO,
                fn: function(btn) {
                    if (btn == 'yes') {
                        var sm = dataTable.getSelectionModel();
                        var sel = sm.getSelections();
                        var data = '';
                        for (i = 0; i<sel.length; i++) {
                            data = data + sel[i].get('id_permohonan') + ';';
                        }
						


                        Ext.Ajax.request({
                            url: BASE_URL + 'permohonan/delete',
                            method: 'POST',
                            params: { postdata: data }
						

                        });
                        listData.load();
                    }
                }
            });
					}
				else
				{
					Ext.MessageBox.alert('Message', 'Pilih data!');
				}
			
			}
            }
		, */'->', searchData]
        });

        
                   
        function deleteData() {
            Ext.Msg.show({
                title: 'Confirm',
                msg: 'Hapus Data ini ?',
                buttons: Ext.Msg.YESNO,
                fn: function(btn) {
                    if (btn == 'yes') {
                        var sm = dataTable.getSelectionModel();
                        var sel = sm.getSelections();
                        var data = '';
                        for (i = 0; i<sel.length; i++) {
                            data = data + sel[i].get('id_permohonan') + ';';
                        }
						


                        Ext.Ajax.request({
                            url: BASE_URL + 'permohonan/delete',
                            method: 'POST',
                            params: { postdata: data }
						

                        });
                        listData.load();
                    }
                }
            });
        }

        var cbGrid = new Ext.grid.CheckboxSelectionModel();

       var dataTable = new Ext.grid.EditorGridPanel({
            frame: true, border: true, stripeRows: true,sm:cbGrid,
            store: listData, loadMask: true, 
            style: 'margin:0 auto;', width: 800,
            columns: [
              new Ext.grid.RowNumberer(), cbGrid, {
			        header: 'No Permohonan',
                    dataIndex: 'no_permohonan',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Tanggal Terima surat',
                    dataIndex: 'tgl_terimasurat',
                    sortable: true,
                    width: 100
                }, {
			        header: 'No Surat',
                    dataIndex: 'no_surat',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Pemohon',
                    dataIndex: 'pemohon',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Lembaga',
                    dataIndex: 'id_lembaga',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Program',
                    dataIndex: 'id_program',
                    sortable: true,
                    width: 100
                }, {
			        header: 'Permohonan',
                    dataIndex: 'permohonan',
                    sortable: true,
                    width: 30
                }, {
			        header: 'Pernyataan',
                    dataIndex: 'pernyataan',
                    sortable: true,
                    width: 30
                }, {
			        header: 'Formulir',
                    dataIndex: 'formulir',
                    sortable: true,
                    width: 30
                }, {
			        header: 'Izin Operasional',
                    dataIndex: 'izin_operasional',
                    sortable: true,
                    width: 30

                }, {
			        header: 'Akta',
                    dataIndex: 'akta',
                    sortable: true,
                    width: 30
                }, {
			        header: 'Instrumen',
                    dataIndex: 'instrumen',
                    sortable: true,
                    width: 30
                },  {
			        header: 'Lampiran',
                    dataIndex: 'lampiran',
                    sortable: true,
                    width: 30
                },{ 
		             header: 'Keterangan permohonan',
                    dataIndex: 'keterangan',
                    sortable: true,
                    width: 100
                }
				, { 
		             header: 'No Surat Balasan',
                    dataIndex: 'no_suratbalasan',
                    sortable: true,
                    width: 100
                }  
				, { 
		             header: 'Tanggal Pengiriman',
                    dataIndex: 'tgl_pengiriman',
                    sortable: true,
                    width: 100
                }  
				, { 
		             header: 'Keterangan Balasan',
                    dataIndex: 'keterangan_balasan',
                    sortable: true,
                    width: 100
                }  
				, { 
		             header: 'Status',
                    dataIndex: 'proses',
                    sortable: true,
                    width: 100
                }  
            ],
			
		viewConfig: {
			forceFit: true
		},
       width: '100%',
		height:580,
		split: true,
		region: 'north',

            listeners: {
                'rowclick': function() {
                    var sm = dataTable.getSelectionModel();
                    var sel = sm.getSelections();
                }
            },
			 
            tbar: tbData,
			
            bbar: new Ext.PagingToolbar({
                pageSize: 100,
                store: listData,
                displayInfo: true
            })
        });

      dataTable.render('dataTable');	
        listData.load();
    });
    </script>
    <style type='text/css'>
        #divgrid {
            background: #e9e9e9;
            border: 1px solid #d3d3d3;
            margin: 20px;
            padding: 20px;
        }
    </style>

    <title>permohonan</title>
</head>
<body>

 <div id='dataTable'></div>
	
    <div style="display:none">
<? 
$lembaga="";


$sql=$this->db->query("select * from lembaga order by nama_lembaga asc");
foreach($sql->result() as $row){
$lembaga .="<option value='".$row->id_lembaga."'>".$row->nama_lembaga."</option>";
}
$sqlprogram=$this->db->query("select * from program order by kode_program asc");
foreach($sqlprogram->result() as $rowprogram){
$program .="<option value='".$rowprogram->id_program."'>".$rowprogram->kode_program." / ".$rowprogram->nama_program."</option>";
}

?>
    
<select id="lembagaadd">
<?=$lembaga?>
</select>
<select id="lembagaedit">
<?=$lembaga?>
</select>
<select id="programadd">
<?=$program?>
</select>
<select id="programedit">
<?=$program?>
</select>
    </div>
</body>
</html>