<?php

$akses=explode(";",$this->session->userdata( "role"));

?>
<script>
		Banpt.classData =
		{"id":"pkg-Ext","text":"Menu","singleClickExpand":true, children:[
		{"id":"pkg-Ext.profil","text":"Profil","singleClickExpand":true, children:[
/*{"href":"home/permohonan","html":"tes","text":"Permohonan ","title":"Karyawan","id":"Ext.berkas.Permohonan ","isClass":true,"cls":"cls","leaf":true}	*/			
{"href":"home/editpass","html":"tes","text":"Edit Password ","title":"User","id":"Ext.profil.Edit Password ","isClass":true,"cls":"cls","leaf":true},																																		  ]}
																		 
																		   ,{"id":"pkg-Ext.berkas","text":"Berkas","singleClickExpand":true, children:[
																		      <? if($akses[7]==1){?>
{"href":"home/suratmasuk","html":"tes","text":"Surat Masuk ","title":"Surat Masuk","id":"Ext.berkas.Surat Masuk ","isClass":true,"cls":"cls","leaf":true}	
<? } 
if($akses[7]==1&&$akses[1]==1 || $akses[7]==1&&$akses[5]==1|| $akses[7]==1&&$akses[2]==1 ){
?>	
,
<? } ?>
																		    <? if($akses[1]==1){?>
{"href":"home/permohonan","html":"tes","text":"Permohonan ","title":"Permohonan","id":"Ext.berkas.Permohonan ","isClass":true,"cls":"cls","leaf":true}	
<? } 
if($akses[1]==1&&$akses[2]==1 || $akses[1]==1&&$akses[5]==1 ){
?>	
,
<? } ?>
<? if($akses[2]==1){?>
{"href":"home/balasan","html":"tes","text":"Surat Balasan ","title":"Surat Balasan","id":"Ext.berkas.Surat Balasan ","isClass":true,"cls":"cls","leaf":true}
<? } if($akses[2]==1&&$akses[5]==1  ){
?>	
,
<? } ?>
<? if($akses[5]==1){?>
{"href":"home/pendaftaran","html":"tes","text":"Pendaftaran ","title":"Pendaftaran","id":"Ext.berkas.Pendaftaran ","isClass":true,"cls":"cls","leaf":true}

<? } ?>	
																																				  ]}
  <?php if($akses[3]==1){?>
 ,{"id":"pkg-Ext.lembaga","text":"Lembaga","singleClickExpand":true, children:[
{"href":"home/lembaga","html":"tes","text":"Lembaga ","title":"Lembaga","id":"Ext.lembaga.Lembaga ","isClass":true,"cls":"cls","leaf":true}																																						  ]}
			
			  <?php } if($akses[4]==1){?>
 ,{"id":"pkg-Ext.asesor","text":"Asesor","singleClickExpand":true, children:[
{"href":"home/asesor","html":"tes","text":"Asesor ","title":"Asesor","id":"Ext.asesor.Asesor ","isClass":true,"cls":"cls","leaf":true},
{"href":"home/lamaranasesor","html":"tes","text":"Lamaran Asesor ","title":":Lamaran Asesor","id":"Ext.asesor.Lamaran Asesor ","isClass":true,"cls":"cls","leaf":true}																																						  ]}
  <?php } if($akses[6]==1){?>
 ,{"id":"pkg-Ext.akred","text":"Akreditasi","singleClickExpand":true, children:[
{"href":"home/akreditasi","html":"tes","text":"Akreditasi ","title":"Akreditasi","id":"Ext.akred.Akreditasi ","isClass":true,"cls":"cls","leaf":true}																																						  ]}
																		  
																		    <?php } if($akses[0]==1){?>
                ,{"id":"pkg-Ext.akreditasi","text":"Master","singleClickExpand":true, children:[
																																
                {"href":"home/karyawan","html":"tes","text":"Karyawan ","title":"Karyawan","id":"Ext.akreditasi.Karyawan ","isClass":true,"cls":"cls","leaf":true},
								{"href":"home/news","html":"tes","text":"Berita ","title":"Berita","id":"Ext.akreditasi.Berita ","isClass":true,"cls":"cls","leaf":true},
									{"href":"home/komentar","html":"tes","text":"Komentar ","title":"Komentar Pengguna","id":"Ext.akreditasi.Komentar ","isClass":true,"cls":"cls","leaf":true},
				
				{"href":"home/user","html":"tes","text":"User ","title":"User","id":"Ext.akreditasi.User ","isClass":true,"cls":"cls","leaf":true},	
				
				{"href":"home/program","html":"tes","text":"Program ","title":"Program","id":"Ext.akreditasi.Program ","isClass":true,"cls":"cls","leaf":true},	
				{"href":"home/provinsi","html":"tes","text":"Provinsi ","title":"Provinsi","id":"Ext.akreditasi.Provinsi ","isClass":true,"cls":"cls","leaf":true},	
				{"href":"home/kabupatenkota","html":"tes","text":"Kabupaten/Kota ","title":"Kabupaten/Kota","id":"Ext.akreditasi.Kabupaten/Kota ","isClass":true,"cls":"cls","leaf":true},
				
				{"href":"home/jabatan","html":"tes","text":"Jabatan ","title":"Jabatan","id":"Ext.akreditasi.Jabatan ","isClass":true,"cls":"cls","leaf":true}
				  
				 
				]}
				<?php } ?>
				/*,
				{"id":"pkg-Ext.logout","text":"Logout","singleClickExpand":true, children:[
					{"href":"login/logout","text":"Logout ","title":"Logout","id":"Ext.logout.Logout ","cls":"cls","leaf":true}																		   
																							   ]}
				,
                {"id":"pkg-Ext.grid","text":"Portal","iconCls":"icon-pkg","cls":"package","singleClickExpand":true, children:[
                {"href":"output/Ext.grid.AbstractSelectionModel.html","text":"AbstractSelectionModel","id":"Ext.grid.AbstractSelectionModel","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				]}
				,
                {"id":"pkg-Ext.list","text":"Managemnt Report","iconCls":"icon-pkg","cls":"package","singleClickExpand":true, children:[
                {"href":"output/Ext.list.BooleanColumn.html","text":"BooleanColumn","id":"Ext.list.BooleanColumn","isClass":true,"iconCls":"icon-cls","cls":"cls","leaf":true}
				]}*/
				
				
				
				]};
				
				
				
        Banpt.icons = {
			};
    </script>